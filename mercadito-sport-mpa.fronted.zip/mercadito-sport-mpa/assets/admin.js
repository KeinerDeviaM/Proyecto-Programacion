// assets/admin.js — Admin: pedidos + productos (aprobación) 
(function(){
  const $  = (s,r=document)=> r.querySelector(s);
  const $$ = (s,r=document)=> Array.from(r.querySelectorAll(s));

  Auth.ensureAdmin("./login.html");

  // ===== Nav tabs =====
  $$(".tab").forEach(t=>{
    t.addEventListener("click", ()=>{
      $$(".tab").forEach(x=>x.classList.remove("active"));
      t.classList.add("active");
      const id = t.dataset.tab;
      $("#tab-orders").classList.toggle("hidden", id!=="orders");
      $("#tab-products").classList.toggle("hidden", id!=="products");
    });
  });

  // ===== Pedidos =====
  function fmt(n){ return new Intl.NumberFormat("es-CO",{style:"currency",currency:"COP"}).format(n||0); }
  function loadOrders(){ try{ return JSON.parse(localStorage.getItem("ms_orders")||"[]"); }catch{ return []; } }
  function saveOrders(arr){ localStorage.setItem("ms_orders", JSON.stringify(arr||[])); }

  function kpis(orders){
    const revenue = orders.reduce((a,o)=> a + (o.totals?.total||0), 0);
    const count   = orders.length;
    const aov     = count ? Math.round(revenue / count) : 0;
    const now = Date.now(), weekMs = 7*24*3600*1000;
    const week = orders.filter(o => (now - new Date(o.date).getTime()) <= weekMs)
                       .reduce((a,o)=> a + (o.totals?.total||0), 0);
    $("#kpiRevenue").textContent = fmt(revenue);
    $("#kpiOrders").textContent  = String(count);
    $("#kpiAOV").textContent     = fmt(aov);
    $("#kpiWeek").textContent    = fmt(week);
  }
  function orderRow(o){
    const total = o.totals?.total || 0;
    const email = o.customer?.email || o.userEmail || "Invitado";
    const status = o.status || "pagado";
    return `
      <tr data-id="${o.id}">
        <td><strong>${o.id}</strong></td>
        <td>${new Date(o.date).toLocaleString()}</td>
        <td>${email}</td>
        <td><strong>${fmt(total)}</strong></td>
        <td><span class="badge">${status}</span></td>
        <td class="actions">
          <button class="btn outline small see">Ver</button>
          <button class="btn outline small mark">Marcar enviado</button>
          <button class="btn outline small del">Eliminar</button>
        </td>
      </tr>
      <tr class="details" data-for="${o.id}" style="display:none">
        <td colspan="6">
          <div class="pad">
            <strong>Artículos</strong>
            <ul style="margin:6px 0 0 16px">
              ${(o.items||[]).map(it=> `<li>${it.qty} × ${it.name||it.id} — ${fmt(it.lineTotal)}</li>`).join("")}
            </ul>
          </div>
        </td>
      </tr>
    `;
  }
  function renderOrders(){
    const orders = loadOrders();
    kpis(orders);
    const body = $("#ordersBody");
    body.innerHTML = orders.map(orderRow).join("") || `<tr><td colspan="6" class="meta">No hay pedidos aún</td></tr>`;
    $$(".see", body).forEach(btn=> btn.addEventListener("click", (e)=>{
      const tr = e.currentTarget.closest("tr");
      const id = tr.dataset.id;
      const det = document.querySelector(`tr.details[data-for="${id}"]`);
      if(det) det.style.display = det.style.display === "none" ? "table-row" : "none";
    }));
    $$(".mark", body).forEach(btn=> btn.addEventListener("click", (e)=>{
      const id = e.currentTarget.closest("tr").dataset.id;
      const arr = loadOrders();
      const o = arr.find(x=> x.id === id);
      if(o){ o.status = "enviado"; saveOrders(arr); renderOrders(); }
    }));
    $$(".del", body).forEach(btn=> btn.addEventListener("click", (e)=>{
      const id = e.currentTarget.closest("tr").dataset.id;
      if(!confirm("¿Eliminar pedido del historial?")) return;
      const arr = loadOrders().filter(x=> x.id !== id);
      saveOrders(arr); renderOrders();
    }));

    $("#exportCsv").addEventListener("click", ()=>{
      const orders = loadOrders();
      const rows = [
        ["id","date","email","total","status","items"],
        ...orders.map(o=>[
          o.id,
          o.date,
          o.customer?.email || o.userEmail || "",
          o.totals?.total || 0,
          o.status || "pagado",
          (o.items||[]).map(it=> `${it.qty}x ${it.name||it.id}`).join(" | ")
        ])
      ];
      const csv = rows.map(r => r.map(s => `"${String(s).replace(/"/g,'""')}"`).join(",")).join("\n");
      const blob = new Blob([csv], {type:"text/csv;charset=utf-8"});
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "pedidos.csv";
      a.click();
      URL.revokeObjectURL(a.href);
    });

    $("#clearOrders").addEventListener("click", ()=>{
      if(confirm("¿Borrar TODO el historial de pedidos?")){ saveOrders([]); renderOrders(); }
    });
  }

  // ===== Productos =====
  function subRowHTML(s){
    const p = s.product || {};
    return `
      <tr data-id="${s.id}">
        <td><div class="thumb">${p.image?`<img src="${p.image}">`:""}</div></td>
        <td><strong>${p.name||"(sin nombre)"}</strong><div class="mini">${p.department||""} • ${p.sport||""}</div></td>
        <td>${s.ownerEmail||""}</td>
        <td>${MSStore.fmt(p.price||0)}</td>
        <td>${p.stock||0}</td>
        <td>${new Date(s.createdAt).toLocaleString()}</td>
        <td class="actions">
          <a class="btn outline small" href="./sell.html?edit=${s.id}">Editar</a>
          <button class="btn outline small ok">Aprobar</button>
          <button class="btn outline small reject">Rechazar</button>
          <button class="btn outline small del">Eliminar</button>
        </td>
      </tr>
    `;
  }
  function catRowHTML(p){
    return `
      <tr data-id="${p.id}">
        <td><div class="thumb">${p.image?`<img src="${p.image}">`:""}</div></td>
        <td><strong>${p.name}</strong><div class="mini">${p.description||""}</div></td>
        <td>${p.department} / ${p.type}</td>
        <td>${p.brand||""}</td>
        <td>${MSStore.fmt(p.discount>0 ? Math.round(p.price*(1-p.discount/100)) : p.price)} ${p.discount>0?`<span class="mini" style="text-decoration:line-through; color:var(--muted)">${MSStore.fmt(p.price)}</span>`:""}</td>
        <td>${p.stock||0}</td>
        <td class="actions">
          <button class="btn outline small rm">Quitar</button>
        </td>
      </tr>
    `;
  }
  function renderProducts(){
    // Pendientes
    const pend = JSON.parse(localStorage.getItem("ms_products_submissions")||"[]").filter(s=> s.status==="pendiente");
    $("#subsBody").innerHTML = pend.map(subRowHTML).join("") || `<tr><td colspan="7" class="meta">No hay envíos pendientes</td></tr>`;

    // Catálogo
    const cat = JSON.parse(localStorage.getItem("ms_products_catalog")||"[]");
    $("#catalogBody").innerHTML = cat.map(catRowHTML).join("") || `<tr><td colspan="7" class="meta">Catálogo vacío (aprobá envíos o crea desde tu backend)</td></tr>`;

    // Acciones
    $$("#subsBody .ok").forEach(btn => btn.addEventListener("click", (e)=>{
      const id = e.currentTarget.closest("tr").dataset.id;
      const product = MSStore.approveSubmission(id);
      if(product){ alert("Aprobado y agregado al catálogo."); renderProducts(); }
    }));
    $$("#subsBody .reject").forEach(btn => btn.addEventListener("click", (e)=>{
      const id = e.currentTarget.closest("tr").dataset.id;
      const reason = prompt("Motivo del rechazo (opcional):","Datos incompletos");
      if(MSStore.rejectSubmission(id, reason||"")){ renderProducts(); }
    }));
    $$("#subsBody .del").forEach(btn => btn.addEventListener("click", (e)=>{
      const id = e.currentTarget.closest("tr").dataset.id;
      if(confirm("Eliminar envío del sistema?")){
        // admin puede borrar siempre
        MSStore.deleteSubmission(id, "", true);
        renderProducts();
      }
    }));
    $$("#catalogBody .rm").forEach(btn => btn.addEventListener("click", (e)=>{
      const id = e.currentTarget.closest("tr").dataset.id;
      if(confirm("Quitar del catálogo? (no borra el envío)")){
        MSStore.removeFromCatalog(id);
        renderProducts();
      }
    }));

    $("#clearCatalog").addEventListener("click", ()=>{
      if(confirm("¿Vaciar catálogo aprobado?")){
        localStorage.setItem("ms_products_catalog","[]");
        renderProducts();
      }
    });
  }

  // Init
  renderOrders();
  renderProducts();
})();
