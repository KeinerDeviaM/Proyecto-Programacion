// assets/store.js — Carrito + Órdenes + Catálogo con productos aprobados (localStorage)
(function(w){
  const LS = {
    CART: "ms_cart",
    ORDERS: "ms_orders",
    LAST_ORDER: "ms_last_order",
    CATALOG: "ms_products_catalog",        // productos aprobados/administrados por el admin
    SUBMISSIONS: "ms_products_submissions" // envíos de usuarios (pendientes/aprobados/rechazados)
  };

  // ===== Util =====
  const fmt = (n)=> new Intl.NumberFormat("es-CO",{style:"currency",currency:"COP"}).format(n||0);
  const uid = (p="p")=> p + Math.random().toString(36).slice(2,8) + Date.now().toString(36).slice(-4);

  const read = (k,def)=> { try{ return JSON.parse(localStorage.getItem(k) || JSON.stringify(def)); }catch{ return def; } };
  const write = (k,val)=> localStorage.setItem(k, JSON.stringify(val));

  // ===== Productos =====
  function baseProducts(){
    // Del seed estático (app.js). Si no existe, devolvemos array vacío
    return Array.isArray(w.PRODUCTS) ? w.PRODUCTS : [];
  }
  function catalogProducts(){
    return read(LS.CATALOG, []);
  }
  function setCatalog(arr){
    write(LS.CATALOG, arr || []);
  }
  function submissions(){
    return read(LS.SUBMISSIONS, []);
  }
  function setSubmissions(arr){
    write(LS.SUBMISSIONS, arr || []);
  }

  // Devuelve todos los productos visibles en tienda (seed + aprobados por admin)
  function getProducts(){
    return [...baseProducts(), ...catalogProducts()];
  }

  // ===== Submissions de usuarios =====
  function submitProduct(draft, ownerEmail){
    // normaliza y guarda como "pendiente"
    const p = normalizeProduct(draft);
    const sub = {
      id: uid("sub_"),
      status: "pendiente",
      ownerEmail: (ownerEmail || "").toLowerCase(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      product: p
    };
    const arr = submissions();
    arr.unshift(sub);
    setSubmissions(arr);
    return sub.id;
  }
  function normalizeProduct(p){
    // valores por defecto seguros
    const price = Number(p.price || 0);
    const discount = Number(p.discount || 0);
    const stock = Number(p.stock || 0);
    const rating = Number(p.rating || 4.4);
    const reviews = Number(p.reviews || 0);

    let colors = [];
    if(Array.isArray(p.colors) && p.colors.length){
      colors = p.colors.map(c => ({ name: c.name || "Color", hex: c.hex || "#111827" }));
    }else if(p.colorName || p.colorHex){
      colors = [{ name: p.colorName || "Color", hex: p.colorHex || "#111827" }];
    }

    const tags = Array.isArray(p.tags) ? p.tags : String(p.tags||"").split(",").map(s=>s.trim()).filter(Boolean);

    return {
      id: p.id || uid("up_"), // id temporal para submissions
      name: String(p.name||"Producto sin nombre").trim(),
      price, discount, stock, rating, reviews,
      department: p.department || "Novedades",
      sport: p.sport || "Training",
      type: p.type || "accesorios",
      brand: p.brand || "Marca",
      colors,
      tags,
      image: p.image || "",
      description: p.description || ""
    };
  }
  function listMySubmissions(ownerEmail){
    const email = (ownerEmail||"").toLowerCase();
    return submissions().filter(s => s.ownerEmail === email);
  }
  function getSubmission(id){
    return submissions().find(s => s.id === id) || null;
  }
  function updateSubmission(id, patch, whoEmail, isAdmin=false){
    const arr = submissions();
    const i = arr.findIndex(s => s.id === id);
    if(i < 0) return false;
    const s = arr[i];

    // Permisos: el dueño puede editar solo si está pendiente o rechazado; admin siempre
    if(!isAdmin){
      const me = (whoEmail||"").toLowerCase();
      if(s.ownerEmail !== me) return false;
      if(!["pendiente","rechazado"].includes(s.status)) return false;
    }

    const np = normalizeProduct({ ...s.product, ...(patch.product||{}) });
    arr[i] = { ...s, ...patch, product: np, updatedAt: new Date().toISOString() };
    setSubmissions(arr);
    return true;
  }
  function deleteSubmission(id, whoEmail, isAdmin=false){
    const arr = submissions();
    const idx = arr.findIndex(s => s.id === id);
    if(idx < 0) return false;

    if(!isAdmin){
      const me = (whoEmail||"").toLowerCase();
      if(arr[idx].ownerEmail !== me) return false;
      if(arr[idx].status === "aprobado") return false;
    }
    arr.splice(idx,1);
    setSubmissions(arr);
    return true;
  }

  // ===== Admin: aprobar / rechazar =====
  function approveSubmission(id){
    const arr = submissions();
    const i = arr.findIndex(s => s.id === id);
    if(i < 0) return null;
    const s = arr[i];
    const product = { ...s.product, id: uid("ap_") }; // nuevo id definitivo en catálogo

    // añade al catálogo
    const cat = catalogProducts();
    cat.unshift(product);
    setCatalog(cat);

    // marca submission
    arr[i] = { ...s, status:"aprobado", updatedAt: new Date().toISOString(), approvedProductId: product.id };
    setSubmissions(arr);
    return product;
    // Nota: si quieres que al rechazar vuelva a pendiente al editar, se puede.
  }
  function rejectSubmission(id, reason=""){
    const arr = submissions();
    const i = arr.findIndex(s => s.id === id);
    if(i < 0) return false;
    arr[i] = { ...arr[i], status:"rechazado", rejectReason: reason||undefined, updatedAt: new Date().toISOString() };
    setSubmissions(arr);
    return true;
  }
  function removeFromCatalog(id){
    const cat = catalogProducts().filter(p => p.id !== id);
    setCatalog(cat);
  }

  // ===== Carrito =====
  function getCart(){
    return read(LS.CART, {}); // {id: qty}
  }
  function setCart(obj){
    write(LS.CART, obj||{});
  }
  function addToCart(id, qty=1){
    const cart = getCart();
    cart[id] = (cart[id]||0) + qty;
    if(cart[id] <= 0) delete cart[id];
    setCart(cart);
  }
  function removeFromCart(id){
    const cart = getCart();
    delete cart[id];
    setCart(cart);
  }
  function setQty(id, qty){
    const cart = getCart();
    if(qty<=0) delete cart[id]; else cart[id] = qty;
    setCart(cart);
  }
  function clearCart(){ setCart({}); }

  function cartItems(){
    const all = getProducts();
    const cart = getCart();
    const map = new Map(all.map(p=>[p.id,p]));
    const out = [];
    Object.entries(cart).forEach(([id,qty])=>{
      const p = map.get(id);
      if(!p) return;
      const unit = p.discount>0 ? Math.round(p.price*(1-p.discount/100)) : p.price;
      out.push({
        id: p.id, name: p.name, brand: p.brand, sport: p.sport, image: p.image, qty,
        unitPrice: unit, lineTotal: unit * qty
      });
    });
    return out;
  }
  function totals(){
    const items = cartItems();
    const sub = items.reduce((a,it)=> a + it.lineTotal, 0);
    const ship = sub >= 99900 ? 0 : 9900;
    const tax = Math.round(sub * 0.19);
    const total = sub + ship + tax;
    return { sub, ship, tax, total };
  }
  function genOrderId(){ return "MS" + Date.now().toString(36).toUpperCase(); }

  w.MSStore = {
    // utils
    fmt, uid,
    // catálogo
    getProducts,
    submitProduct, listMySubmissions, getSubmission, updateSubmission, deleteSubmission,
    approveSubmission, rejectSubmission, removeFromCatalog,
    // carrito
    addToCart, removeFromCart, setQty, clearCart, cartItems, totals, genOrderId
  };
})(window);
