// assets/cart.js — lógica de la página carrito
(function () {
  const $ = (s, r=document)=> r.querySelector(s);
  const $$= (s, r=document)=> Array.from(r.querySelectorAll(s));
  const S = window.MSStore;

  const body    = $("#cartBody");
  const empty   = $("#empty");
  const tableW  = $("#tableWrap");
  const vaciar  = $("#vaciar");
  const subEl   = $("#sub");
  const shipEl  = $("#ship");
  const taxEl   = $("#tax");
  const totalEl = $("#total");
  const goPay   = $("#goCheckout");

  function rowHTML(it){
    return `
      <tr data-id="${it.id}">
        <td>
          <div class="row" style="gap:10px;align-items:center">
            <div class="img" style="width:72px;height:72px;overflow:hidden;border-radius:10px">
              <img src="${it.image}" alt="${it.name}" style="width:100%;height:100%;object-fit:cover">
            </div>
            <div>
              <div><strong>${it.name}</strong></div>
              <div class="meta">${it.department} • ${it.sport} • ${it.brand}</div>
              ${it.discount>0 ? `<span class="badge danger" style="margin-top:4px;display:inline-block">-${it.discount}%</span>`:""}
            </div>
          </div>
        </td>
        <td>${S.fmt(it.unitPrice)}</td>
        <td>
          <div class="row" style="gap:6px">
            <button class="btn outline small qty-dec">−</button>
            <input class="pill qty-input" value="${it.qty}" style="width:48px;text-align:center"/>
            <button class="btn outline small qty-inc">＋</button>
          </div>
        </td>
        <td><strong>${S.fmt(it.lineTotal)}</strong></td>
        <td><button class="btn outline small remove">✕</button></td>
      </tr>
    `;
  }

  function updateTotals(){
    const t = S.totals();
    subEl.textContent   = S.fmt(t.sub);
    shipEl.textContent  = S.fmt(t.ship);
    taxEl.textContent   = S.fmt(t.tax);
    totalEl.textContent = S.fmt(t.total);
  }

  function render(){
    const items = S.cartItems();
    const has = items.length>0;
    empty.style.display   = has ? "none" : "block";
    tableW.style.display  = has ? "block" : "none";
    goPay.classList.toggle("disabled", !has);
    goPay.setAttribute("aria-disabled", String(!has));

    if(!has){ updateTotals(); return; }

    body.innerHTML = items.map(rowHTML).join("");
    updateTotals();

    $$(".qty-dec", body).forEach(btn=> btn.addEventListener("click", (e)=>{
      const tr = e.currentTarget.closest("tr");
      const id = tr.dataset.id;
      const input = tr.querySelector(".qty-input");
      S.setQty(id, Math.max(1, (parseInt(input.value)||1) - 1));
      render();
    }));
    $$(".qty-inc", body).forEach(btn=> btn.addEventListener("click", (e)=>{
      const tr = e.currentTarget.closest("tr");
      const id = tr.dataset.id;
      const input = tr.querySelector(".qty-input");
      S.setQty(id, Math.max(1, (parseInt(input.value)||1) + 1));
      render();
    }));
    $$(".qty-input", body).forEach(inp=> inp.addEventListener("change", (e)=>{
      const tr = e.currentTarget.closest("tr");
      const id = tr.dataset.id;
      S.setQty(id, Math.max(1, parseInt(e.target.value)||1));
      render();
    }));
    $$(".remove", body).forEach(btn=> btn.addEventListener("click", (e)=>{
      const tr = e.currentTarget.closest("tr");
      S.removeFromCart(tr.dataset.id);
      render();
    }));
  }

  vaciar?.addEventListener("click", ()=>{ if(confirm("¿Vaciar carrito?")){ S.clearCart(); render(); } });
  render();
})();
