// assets/sell.js — Subir producto (cliente). Soporta URL o archivo (base64). Edit mode con ?edit=ID
(function(){
  const $ = (s,r=document)=> r.querySelector(s);
  Auth.ensureLoggedIn("./login.html");
  const session = Auth.getSession();

  const f = {
    name: $("#pName"), price: $("#pPrice"), discount: $("#pDiscount"),
    dept: $("#pDept"), type: $("#pType"), sport: $("#pSport"), brand: $("#pBrand"),
    stock: $("#pStock"), tags: $("#pTags"),
    colorName: $("#pColorName"), colorHex: $("#pColorHex"),
    desc: $("#pDesc"), imgUrl: $("#pImgUrl"), imgFile: $("#pImgFile"), preview: $("#pPreview")
  };
  const editHint = $("#editHint"), editIdEl = $("#editId");
  const qs = new URLSearchParams(location.search);
  const editId = qs.get("edit");

  function loadEdit(){
    if(!editId) return;
    const sub = MSStore.getSubmission(editId);
    if(!sub){ alert("No se encontró el envío a editar."); return; }
    if(sub.ownerEmail !== session.email && session.role !== "admin"){ alert("Sin permisos."); return; }
    if(sub.status === "aprobado"){ alert("Este envío ya fue aprobado, no se puede editar."); return; }

    const p = sub.product;
    f.name.value = p.name || "";
    f.price.value = p.price || 0;
    f.discount.value = p.discount || 0;
    f.dept.value = p.department || "Novedades";
    f.type.value = p.type || "accesorios";
    f.sport.value = p.sport || "";
    f.brand.value = p.brand || "";
    f.stock.value = p.stock || 0;
    f.tags.value = (p.tags||[]).join(", ");
    f.colorName.value = (p.colors?.[0]?.name) || "";
    f.colorHex.value = (p.colors?.[0]?.hex) || "";
    f.desc.value = p.description || "";
    f.imgUrl.value = p.image || "";
    renderPreview(p.image);
    editHint.style.display = "block";
    editIdEl.textContent = sub.id;
  }

  function renderPreview(src){
    if(!src){ f.preview.textContent = "Sin imagen"; f.preview.style.backgroundImage=""; return; }
    f.preview.textContent = "";
    f.preview.style.backgroundImage = `url("${src}")`;
    f.preview.style.backgroundSize = "cover";
    f.preview.style.backgroundPosition = "center";
  }

  f.imgUrl.addEventListener("input", ()=> renderPreview(f.imgUrl.value.trim()));
  f.imgFile.addEventListener("change", (e)=>{
    const file = e.target.files?.[0];
    if(!file) return;
    const rd = new FileReader();
    rd.onload = ()=> { renderPreview(String(rd.result)); };
    rd.readAsDataURL(file);
  });

  function collectImage(){
    return new Promise((resolve)=>{
      const url = f.imgUrl.value.trim();
      const file = f.imgFile.files?.[0];
      if(file){
        const rd = new FileReader();
        rd.onload = ()=> resolve(String(rd.result));
        rd.readAsDataURL(file);
      }else{
        resolve(url);
      }
    });
  }

  function collectDraft(img){
    return {
      name: f.name.value.trim(),
      price: Number(f.price.value || 0),
      discount: Number(f.discount.value || 0),
      department: f.dept.value,
      type: f.type.value,
      sport: f.sport.value.trim(),
      brand: f.brand.value.trim(),
      stock: Number(f.stock.value || 0),
      tags: f.tags.value.split(",").map(s=>s.trim()).filter(Boolean),
      colorName: f.colorName.value.trim(),
      colorHex: f.colorHex.value.trim(),
      description: f.desc.value.trim(),
      image: img || ""
    };
  }

  $("#btnSubmit").addEventListener("click", async ()=>{
    const img = await collectImage();
    const draft = collectDraft(img);
    if(!draft.name || !draft.price){ alert("Nombre y precio son obligatorios."); return; }

    if(editId){
      const ok = MSStore.updateSubmission(editId, { product: draft, status: "pendiente" }, session.email, session.role==="admin");
      if(!ok){ alert("No se pudo actualizar el envío."); return; }
      alert("Envío actualizado y enviado a revisión.");
    }else{
      MSStore.submitProduct(draft, session.email);
      alert("Enviado a revisión. Te avisaremos cuando el admin lo apruebe (demo).");
    }
    location.href = "./account.html";
  });

  $("#btnGuardar").addEventListener("click", async ()=>{
    const img = await collectImage();
    const draft = collectDraft(img);
    if(editId){
      const ok = MSStore.updateSubmission(editId, { product: draft }, session.email, session.role==="admin");
      if(!ok){ alert("No se pudo guardar."); return; }
      alert("Cambios guardados.");
    }else{
      const id = MSStore.submitProduct(draft, session.email);
      alert("Borrador guardado como pendiente.");
      location.href = `./sell.html?edit=${id}`;
    }
  });

  loadEdit();
})();
