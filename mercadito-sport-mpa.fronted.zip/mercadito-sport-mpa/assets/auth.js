// assets/auth.js — Sesiones con contraseña (hash), registro y roles (localStorage)
(function (w, d) {
  "use strict";

  // === Config ===
  const ADMIN_EMAILS = [
    "adminkeiner@gmail.com", // tu correo admin (en minúsculas)
    "admin@demo.com"         // opcional demo
  ];

  const LS_SESSION = "ms_session";
  const LS_USERS   = "ms_users";   // { [email]: {email,name,role,passHash,createdAt} }

  // === Utils ===
  const toLower = (s)=> String(s||"").trim().toLowerCase();

  function readUsers(){
    try { return JSON.parse(localStorage.getItem(LS_USERS) || "{}"); }
    catch { return {}; }
  }
  function writeUsers(db){ localStorage.setItem(LS_USERS, JSON.stringify(db || {})); }

  // SHA-256 hash (Base64). Si no hay WebCrypto, fallback simple (demo).
  async function hashPass(password, email){
    const salt = toLower(email);
    const data = new TextEncoder().encode(`${salt}::${password}`);
    if (w.crypto?.subtle?.digest) {
      const buf = await crypto.subtle.digest("SHA-256", data);
      const bytes = new Uint8Array(buf);
      let bin = ""; bytes.forEach(b => bin += String.fromCharCode(b));
      return btoa(bin);
    } else {
      // Fallback (NO seguro; solo demo offline)
      let h = 0; for (let i=0;i<data.length;i++) { h = (h<<5)-h + data[i]; h |= 0; }
      return "fallback_" + Math.abs(h);
    }
  }

  function isAdminEmail(email){ return ADMIN_EMAILS.includes(toLower(email)); }

  function getSession(){
    try { return JSON.parse(localStorage.getItem(LS_SESSION) || "null"); }
    catch { return null; }
  }
  function setSession(sess){ localStorage.setItem(LS_SESSION, JSON.stringify(sess)); return sess; }
  function clearSession(){ localStorage.removeItem(LS_SESSION); }

  function ensureLoggedIn(redirect="./login.html"){ if(!getSession()) location.href = redirect; }
  function ensureAdmin(redirect="./login.html"){ const s=getSession(); if(!s || s.role!=="admin") location.href = redirect; }

  // === Registro / Login / Cambio de pass ===
  async function register(email, name, password){
    const e = toLower(email);
    if(!e || !password) throw new Error("Correo y contraseña son obligatorios.");
    if(password.length < 8) throw new Error("La contraseña debe tener al menos 8 caracteres.");
    const users = readUsers();
    if(users[e]) throw new Error("Ya existe una cuenta con ese correo.");

    const passHash = await hashPass(password, e);
    const role = isAdminEmail(e) ? "admin" : "user";

    users[e] = {
      email: e,
      name: String(name || "Usuario"),
      role,
      passHash,
      createdAt: new Date().toISOString()
    };
    writeUsers(users);

    return setSession({ email: e, name: users[e].name, role });
  }

  async function login(email, password){
    const e = toLower(email);
    const users = readUsers();
    const u = users[e];
    if(!u) throw new Error("No existe una cuenta con ese correo. Regístrate.");

    const hash = await hashPass(password, e);
    if(hash !== u.passHash) throw new Error("Contraseña incorrecta.");

    const role = isAdminEmail(e) ? "admin" : (u.role || "user");
    if(role !== u.role){ u.role = role; writeUsers(users); }

    return setSession({ email: e, name: u.name, role });
  }

  async function changePassword(email, oldPass, newPass){
    const e = toLower(email);
    const users = readUsers();
    const u = users[e];
    if(!u) throw new Error("Cuenta inexistente.");
    const oldHash = await hashPass(oldPass, e);
    if(oldHash !== u.passHash) throw new Error("Contraseña actual incorrecta.");
    if(!newPass || newPass.length < 8) throw new Error("La nueva contraseña debe tener al menos 8 caracteres.");

    u.passHash = await hashPass(newPass, e);
    writeUsers(users);
    return true;
  }

  function logout(){ clearSession(); }

  // === UI Header / Bottom-nav ===
  function el(tag, attrs = {}, html = "") {
    const node = d.createElement(tag);
    Object.entries(attrs).forEach(([k, v]) => node.setAttribute(k, v));
    if (html) node.innerHTML = html;
    return node;
  }

  function attachHeaderUI(){
    const host = d.querySelector("header .actions");
    if(!host) return;

    host.querySelectorAll("[data-auth-ui]").forEach(n=>n.remove());
    const wrap = el("span", { "data-auth-ui":"1", style:"display:inline-flex;gap:8px;align-items:center" });
    const s = getSession();

    if(!s){
      const btnLogin  = el("a", { href:"./login.html", class:"btn outline small" }, "Iniciar sesión");
      const btnSignup = el("a", { href:"./login.html#registro", class:"btn small" }, "Crear cuenta");
      wrap.append(btnLogin, btnSignup);
    } else {
      const badge = el("span", { class:"badge", title:s.email }, (s.role==="admin" ? "Admin" : "Cliente"));
      const name  = el("span", { class:"meta" }, s.name || s.email);
      const btnAccount = el("a", { href: (s.role==="admin"?"./admin.html":"./account.html"), class:"btn outline small" }, (s.role==="admin"?"Panel Admin":"Cuenta"));
      const btnOut     = el("button", { class:"btn outline small", type:"button" }, "Salir");
      btnOut.addEventListener("click", ()=>{ logout(); location.reload(); });
      wrap.append(badge, name, btnAccount, btnOut);
    }
    host.append(wrap);
    updateBottomNav();
  }

  function updateBottomNav(){
    const link = d.querySelector('.bottom-nav a[data-bnav="account"]');
    if(!link) return;
    const s = getSession();
    const span = link.querySelector("span");
    if(!s) { link.href="./login.html"; if(span) span.textContent="Cuenta"; link.title="Iniciar sesión"; }
    else if(s.role==="admin"){ link.href="./admin.html"; if(span) span.textContent="Admin"; link.title="Panel Admin"; }
    else { link.href="./account.html"; if(span) span.textContent="Cuenta"; link.title="Mi cuenta"; }
  }

  // === Login.html hooks (si existen en la página) ===
  function attachLoginForms(){
    // ---- Login ----
    const loginForm = d.getElementById("loginForm");
    if(loginForm){
      const emailEl = d.getElementById("loginEmail");
      const passEl  = d.getElementById("loginPass");
      const msg     = d.getElementById("loginMsg");
      loginForm.addEventListener("submit", async (e)=>{
        e.preventDefault();
        try{
          const email = emailEl.value.trim();
          const pass  = passEl.value;
          const s = await login(email, pass);
          if(msg) msg.textContent = "¡Sesión iniciada!";
          location.href = (s.role==="admin") ? "./admin.html" : "./account.html";
        }catch(err){
          if(msg) msg.textContent = err.message || "Error al iniciar sesión.";
        }
      });
    }

    // ---- Registro ----
    const regForm = d.getElementById("registerForm");
    if(regForm){
      const emailEl = d.getElementById("registerEmail");
      const nameEl  = d.getElementById("registerName");
      const passEl  = d.getElementById("registerPass");
      const msg     = d.getElementById("registerMsg");
      regForm.addEventListener("submit", async (e)=>{
        e.preventDefault();
        try{
          const email = emailEl.value.trim();
          const name  = (nameEl.value || "").trim();
          const pass  = passEl.value;
          const s = await register(email, name, pass); // firma correcta
          if(msg) msg.textContent = (s.role==="admin") ? "¡Admin creado e iniciado!" : "¡Cuenta creada!";
          location.href = (s.role==="admin") ? "./admin.html" : "./account.html";
        }catch(err){
          if(msg) msg.textContent = err.message || "Error al registrarse.";
        }
      });
    }

    // Cambio de contraseña (opcional) — si agregas un form con estos IDs
    const chForm = d.getElementById("changePassForm");
    if(chForm){
      const curEmail = getSession()?.email;
      const oldEl = d.getElementById("oldPass");
      const newEl = d.getElementById("newPass");
      const msg  = d.getElementById("changePassMsg");
      chForm.addEventListener("submit", async (e)=>{
        e.preventDefault();
        try{
          if(!curEmail) throw new Error("Inicia sesión para cambiar tu contraseña.");
          await changePassword(curEmail, oldEl.value, newEl.value);
          if(msg) msg.textContent = "Contraseña actualizada.";
        }catch(err){
          if(msg) msg.textContent = err.message || "No se pudo cambiar.";
        }
      });
    }
  }

  // === Auto init ===
  function autoInit(){
    attachHeaderUI();
    attachLoginForms();
    w.addEventListener("hashchange", attachHeaderUI);
    w.addEventListener("storage", (e)=>{ if(e.key===LS_SESSION || e.key===LS_USERS) attachHeaderUI(); });
  }

  // Exponer API
  const Auth = {
    ADMIN_EMAILS,
    getSession, logout,
    ensureLoggedIn, ensureAdmin,
    register, login, changePassword,
    attachHeaderUI, updateBottomNav, autoInit
  };
  w.Auth = Auth;

  if (d.readyState === "loading") d.addEventListener("DOMContentLoaded", autoInit);
  else autoInit();

})(window, document);
