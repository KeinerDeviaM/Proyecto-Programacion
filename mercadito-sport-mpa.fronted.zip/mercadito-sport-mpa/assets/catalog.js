// assets/catalog.js — Listado por filas laterales + rating/contador desde Reviews
(function(){
  const $  = (s, r=document)=> r.querySelector(s);
  const $$ = (s, r=document)=> Array.from(r.querySelectorAll(s));
  const fmt = n => new Intl.NumberFormat("es-CO",{style:"currency",currency:"COP"}).format(n);
  const qs = new URLSearchParams(location.search);
  const Reviews = window.Reviews;

  const DATA = (window.PRODUCTS || []).slice();

  const catalog     = $("#catalog") || $("#grid") || $("#catalogRows");
  const sorterSel   = $("#sorter");
  const resultCount = $("#resultCount") || $("#resultsCount");
  if(!catalog) return;

  const dept    = catalog.dataset.dept || "";
  const q       = (qs.get("q")||"").toLowerCase();
  const brand   = qs.get("brand") || "";
  const type    = qs.get("type")  || "";
  const onlyNew = qs.has("nuevo");

  let sorter = sorterSel ? sorterSel.value : "featured";
  let perRow = getPerRow();

  function getPerRow(){
    const forced = parseInt((catalog.dataset.perRow || "").trim(), 10);
    if (!Number.isNaN(forced) && forced > 0) return forced;
    const w = window.innerWidth || document.documentElement.clientWidth;
    if (w >= 1400) return 6;
    if (w >= 1024) return 5;
    if (w >= 768)  return 4;
    return 2;
  }

  function chunk(arr, size){
    const out = [];
    for(let i=0; i<arr.length; i+=size) out.push(arr.slice(i, i+size));
    return out;
  }

  // Obtiene rating / total reseñas “vivos”
  function liveStats(p){
    if(!Reviews) return { rating: p.rating||0, reviews: p.reviews||0 };
    const s = Reviews.getStats(p.id);
    if(s.count > 0) return { rating: s.avg, reviews: s.count };
    return { rating: p.rating||0, reviews: p.reviews||0 };
  }

  function getFiltered(){
    let list = DATA.filter(Boolean);

    if(dept){ list = list.filter(p => p.department === dept); }
    if(onlyNew){ list = list.filter(p => (p.tags||[]).includes("nuevo")); }
    if(q){
      const qq = q.trim();
      list = list.filter(p =>
        p.name.toLowerCase().includes(qq) ||
        (p.brand||"").toLowerCase().includes(qq) ||
        (p.sport||"").toLowerCase().includes(qq) ||
        (p.description||"").toLowerCase().includes(qq)
      );
    }
    if(brand){ list = list.filter(p => (p.brand||"") === brand); }
    if(type){  list = list.filter(p => (p.type ||"") === type ); }

    // Augment stats
    list = list.map(p=>{
      const st = liveStats(p);
      return { ...p, _rating: st.rating, _reviews: st.reviews };
    });

    switch(sorter){
      case "price-asc":  list.sort((a,b)=> a.price - b.price); break;
      case "price-desc": list.sort((a,b)=> b.price - a.price); break;
      case "rating":     list.sort((a,b)=> b._rating - a._rating); break;
      case "reviews":    list.sort((a,b)=> b._reviews - a._reviews); break;
      default:           list.sort((a,b)=> (b.discount-a.discount) || (b._reviews-a._reviews));
    }
    return list;
  }

  function starsHTML(r){
    const full = Math.floor(r||0);
    const half = ((r||0)-full>=0.5);
    return `<span class="stars-display" title="${(r||0).toFixed(1)}/5">` +
           Array.from({length:5}).map((_,i)=>{
              if(i<full) return "★";
              if(i===full && half) return "☆";
              return "☆";
           }).join("") + `</span>`;
  }

  function cardHTML(p){
    const final = p.discount>0 ? Math.round(p.price*(1-p.discount/100)) : p.price;
    return `
      <article class="product-card" data-id="${p.id}">
        <figure class="product-thumb">
          <img src="${p.image}" alt="${p.name}" loading="lazy" decoding="async" width="600" height="${Math.round(600/(4/3))}">
          ${p.discount>0 ? `<span class="badge" style="position:absolute; left:8px; top:8px; background:#fee2e2; border-color:#fecaca; color:#991b1b">-${p.discount}%</span>` : ""}
        </figure>
        <div class="product-body">
          <h3 class="product-title">${p.name}</h3>
          <div class="product-meta">${p.department} • ${p.sport} • ${p.brand}</div>
          <div class="row" style="gap:6px;align-items:center;margin-top:4px">
            ${starsHTML(p._rating||p.rating||0)}
            <span class="meta">(${p._reviews||p.reviews||0})</span>
          </div>
          <div class="product-price">
            <span>${fmt(final)}</span>
            ${p.discount>0 ? `<span class="old">${fmt(p.price)}</span>` : ""}
          </div>
          <div class="product-actions">
            <button class="btn outline btn-view" data-id="${p.id}">Ver</button>
            <button class="btn btn-add" data-id="${p.id}">Agregar</button>
          </div>
        </div>
      </article>
    `;
  }

  function render(){
    const data = getFiltered();
    if(resultCount){
      resultCount.textContent = `${data.length} resultado${data.length!==1?'s':''}`;
    }
    const rows = chunk(data, perRow);
    catalog.innerHTML = `
      <div class="catalog-rows" aria-label="Listado de productos por filas">
        ${rows.map((row, i)=> `
          <section class="row-block" aria-roledescription="carrusel">
            <div class="row-head">
              <h2 class="row-title sr-only">Fila ${i+1}</h2>
              <div class="catalog-arrows" aria-hidden="${row.length<=2?'true':'false'}">
                <button class="btn outline arrow" data-row="${i}" data-dir="prev" aria-label="Anterior">‹</button>
                <button class="btn outline arrow" data-row="${i}" data-dir="next" aria-label="Siguiente">›</button>
              </div>
            </div>
            <div class="row-scroll" id="rowTrack-${i}" tabindex="0">
              ${row.map(cardHTML).join("")}
            </div>
          </section>
        `).join("")}
      </div>
    `;

    rows.forEach((_, i)=>{
      const track = $(`#rowTrack-${i}`, catalog);
      const prev  = catalog.querySelector(`.arrow[data-row="${i}"][data-dir="prev"]`);
      const next  = catalog.querySelector(`.arrow[data-row="${i}"][data-dir="next"]`);
      const step  = Math.max(track.clientWidth * 0.8, 320);
      prev?.addEventListener("click", ()=> track.scrollBy({left:-step, behavior:"smooth"}));
      next?.addEventListener("click", ()=> track.scrollBy({left: step, behavior:"smooth"}));
      let isDown=false, startX=0, startLeft=0;
      track.addEventListener("pointerdown", (e)=>{ isDown=true; track.setPointerCapture(e.pointerId); startX=e.clientX; startLeft=track.scrollLeft; });
      track.addEventListener("pointermove", (e)=>{ if(!isDown) return; track.scrollLeft = startLeft + (startX - e.clientX); });
      track.addEventListener("pointerup",   ()=>{ isDown=false; });
      track.addEventListener("pointercancel",()=>{ isDown=false; });
      track.addEventListener("keydown", (e)=>{ if(e.key==='ArrowRight') track.scrollBy({left: 320, behavior:'smooth'}); if(e.key==='ArrowLeft') track.scrollBy({left:-320, behavior:'smooth'}); });
    });

    $$(".btn-add", catalog).forEach(b=>{
      b.addEventListener("click", (e)=>{
        const id = e.currentTarget.dataset.id;
        if(typeof window.addToCart === "function"){ window.addToCart(id); }
        else alert("Agregado al carrito (demo).");
      });
    });
    $$(".btn-view", catalog).forEach(b=>{
      b.addEventListener("click", (e)=>{
        const id = e.currentTarget.dataset.id;
        if(typeof window.openDetail === "function"){ window.openDetail(id); }
        else alert("Abrir detalle: " + id);
      });
    });
  }

  sorterSel?.addEventListener("change", (e)=>{ sorter = e.target.value; render(); });

  let resizeT;
  window.addEventListener("resize", ()=>{
    clearTimeout(resizeT);
    resizeT = setTimeout(()=>{
      const now = getPerRow();
      if(now !== perRow){ perRow = now; render(); }
    }, 120);
  });

  // Re-render cuando lleguen nuevas reseñas
  window.addEventListener("ms:reviews:updated", ()=> render());

  render();
})();
