// assets/minicart.js — Mini Carrito (dropdown) + Toasts
(function () {
  const $  = (s, r=document)=> r.querySelector(s);
  const $$ = (s, r=document)=> Array.from(r.querySelectorAll(s));
  const S  = window.MSStore;
  if(!S){ console.warn("MSStore no encontrado. Carga assets/store.js antes de minicart.js"); return; }

  // Botón en header
  const actions = $('.topbar .actions') || $('.actions') || $('.topbar .container');
  let btn = $('#miniCartBtn');
  if(!btn && actions){
    const wrapper = document.createElement('div');
    wrapper.innerHTML = `
      <button id="miniCartBtn" class="btn outline small" title="Carrito" style="position:relative">
        🛒 <span style="margin-left:6px">Carrito</span>
        <span id="miniCartBadge" style="position:absolute; right:-6px; top:-6px; background:var(--primary); color:#fff; border-radius:9999px; font-size:11px; line-height:1; padding:2px 6px; border:2px solid var(--surface)">0</span>
      </button>
    `;
    actions.appendChild(wrapper.firstElementChild);
    btn = $('#miniCartBtn');
  }
  const badge = $('#miniCartBadge');

  // Panel
  let panel = $('#miniCartPanel');
  if(!panel){
    panel = document.createElement('div');
    panel.id = 'miniCartPanel';
    panel.className = 'mini-cart';
    panel.innerHTML = `
      <div class="mc-head row" style="justify-content:space-between">
        <strong>Tu carrito</strong>
        <button class="btn outline small" id="mcClose">✕</button>
      </div>
      <div class="mc-items" id="mcItems"></div>
      <div class="mc-foot">
        <div class="row" style="justify-content:space-between">
          <span class="meta">Subtotal</span><strong id="mcSub">$0</strong>
        </div>
        <div class="row" style="justify-content:space-between">
          <span class="meta">Envío</span><strong id="mcShip">$0</strong>
        </div>
        <hr style="border:none;border-top:1px solid var(--border);margin:10px 0"/>
        <div class="row" style="gap:8px">
          <a href="./carrito.html" class="btn outline" style="flex:1">Ver carrito</a>
          <a href="./checkout.html" class="btn" style="flex:1">Pagar</a>
        </div>
      </div>
    `;
    document.body.appendChild(panel);
  }
  const itemsBox = $('#mcItems');
  const subEl = $('#mcSub'); const shipEl = $('#mcShip');

  // Toasts
  let toastStack = $('#toastStack');
  if(!toastStack){
    toastStack = document.createElement('div');
    toastStack.id = 'toastStack';
    toastStack.className = 'toast-stack';
    toastStack.setAttribute('aria-live','polite');
    document.body.appendChild(toastStack);
  }
  function showToast(msg, icon='✓'){
    const el = document.createElement('div');
    el.className = 'toast';
    el.innerHTML = `<span class="icon">${icon}</span><span class="msg">${msg}</span>`;
    toastStack.appendChild(el);
    setTimeout(()=>{ el.classList.add('hide'); setTimeout(()=> el.remove(), 220); }, 2200);
  }

  const fmt = S.fmt;
  const count = () => Object.values(S.readCart()||{}).reduce((a,b)=>a+(b?.qty||b|0),0);

  function itemHTML(it){
    return `
      <div class="mc-item" data-id="${it.id}">
        <div class="mc-thumb"><img src="${it.image}" alt="${it.name}"></div>
        <div class="mc-info">
          <div class="name">${it.name}</div>
          <div class="meta">${it.brand} • ${it.sport}</div>
          <div class="mc-qty">
            <button class="btn outline small mc-dec">−</button>
            <input class="pill mc-inp" value="${it.qty}">
            <button class="btn outline small mc-inc">＋</button>
          </div>
        </div>
        <div class="mc-line">
          <span class="price">${fmt(it.lineTotal)}</span>
          <button class="btn outline small remove">✕</button>
        </div>
      </div>
    `;
  }

  function render(){
    const items = S.cartItems();
    if(items.length === 0){
      itemsBox.innerHTML = `<div class="card"><div class="pad"><strong>Aún no has agregado productos.</strong><div class="meta" style="margin-top:6px">Explora el catálogo y vuelve.</div></div></div>`;
    }else{
      itemsBox.innerHTML = items.map(itemHTML).join("");
      $$('.mc-dec', itemsBox).forEach(b=> b.addEventListener('click', e=>{
        const id = e.currentTarget.closest('.mc-item').dataset.id;
        const it = items.find(x=>x.id===id);
        S.setQty(id, Math.max(1, (it?.qty||1) - 1)); refresh();
      }));
      $$('.mc-inc', itemsBox).forEach(b=> b.addEventListener('click', e=>{
        const id = e.currentTarget.closest('.mc-item').dataset.id;
        const it = items.find(x=>x.id===id);
        S.setQty(id, (it?.qty||1) + 1); refresh();
      }));
      $$('.mc-inp', itemsBox).forEach(inp=> inp.addEventListener('change', e=>{
        const id = e.currentTarget.closest('.mc-item').dataset.id;
        S.setQty(id, Math.max(1, parseInt(e.target.value)||1)); refresh();
      }));
      $$('.remove', itemsBox).forEach(btn=> btn.addEventListener('click', e=>{
        const id = e.currentTarget.closest('.mc-item').dataset.id;
        S.removeFromCart(id); refresh(); showToast('Producto eliminado', '🗑️');
      }));
    }
    const t = S.totals(); subEl.textContent = fmt(t.sub); shipEl.textContent = fmt(t.ship);
    if(badge) badge.textContent = count();
  }

  function open(){ panel.classList.add('open'); render(); }
  function close(){ panel.classList.remove('open'); }
  function refresh(){ render(); }

  $('#mcClose')?.addEventListener('click', close);
  btn?.addEventListener('click', ()=> panel.classList.toggle('open'));
  document.addEventListener('keydown', (e)=>{ if(e.key==='Escape') close(); });
  document.addEventListener('click', (e)=>{
    if(!panel.classList.contains('open')) return;
    const inside = panel.contains(e.target); const onBtn = btn && btn.contains(e.target);
    if(!inside && !onBtn) close();
  });

  // Envolver addToCart para abrir panel + toast
  const prevAdd = window.addToCart;
  window.addToCart = function(id, qty=1){
    if(prevAdd && prevAdd !== S.addToCart) prevAdd(id, qty); else S.addToCart(id, qty);
    open(); showToast('Agregado al carrito', '🛒');
  };

  window.addEventListener('storage', (e)=>{ if(e.key === 'ms_cart') refresh(); });

  if(badge) badge.textContent = count();
})();
