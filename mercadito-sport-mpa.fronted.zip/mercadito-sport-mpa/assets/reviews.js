// assets/reviews.js — Reseñas con estrellitas (localStorage)
(function (w, d) {
  "use strict";

  const LS_KEY = "ms_reviews"; // { [productId]: Review[] }
  const fmtDate = (iso) => new Date(iso).toLocaleDateString("es-CO", { year:"numeric", month:"short", day:"2-digit" });

  function load() {
    try { return JSON.parse(localStorage.getItem(LS_KEY) || "{}"); }
    catch { return {}; }
  }
  function save(db) { localStorage.setItem(LS_KEY, JSON.stringify(db || {})); }

  function getList(productId) {
    const db = load();
    return (db[productId] || []).slice().sort((a,b)=> new Date(b.date) - new Date(a.date));
  }

  // Promedio y conteo
  function getStats(productId) {
    const list = getList(productId);
    if (!list.length) return { avg: 0, count: 0 };
    const sum = list.reduce((a, r) => a + (Number(r.rating) || 0), 0);
    return { avg: sum / list.length, count: list.length };
  }

  function getMine(productId, email) {
    const list = getList(productId);
    const e = String(email||"").toLowerCase();
    return list.find(r => r.userEmail === e) || null;
  }

  function upsert(productId, { rating, title, body }, session) {
    if (!session) throw new Error("Debes iniciar sesión para reseñar.");
    const r = Math.max(1, Math.min(5, Number(rating || 0)));
    if (!r) throw new Error("Selecciona una calificación de 1 a 5.");
    const db = load();
    const list = db[productId] || [];
    const now = new Date().toISOString();
    const email = String(session.email || "").toLowerCase();
    const name  = session.name || "Usuario";

    const existing = list.find(x => x.userEmail === email);
    if (existing) {
      existing.rating = r;
      existing.title  = String(title||"").trim().slice(0,120);
      existing.body   = String(body||"").trim().slice(0,1500);
      existing.date   = now;
    } else {
      list.push({
        id: `${Date.now()}_${Math.random().toString(16).slice(2)}`,
        productId,
        rating: r,
        title: String(title||"").trim().slice(0,120) || "Sin título",
        body:  String(body||"").trim().slice(0,1500) || "",
        userEmail: email,
        userName: name,
        date: now
      });
    }
    db[productId] = list;
    save(db);
    w.dispatchEvent(new CustomEvent("ms:reviews:updated", { detail: { productId }}));
    return true;
  }

  function remove(productId, reviewId, session) {
    if (!session) throw new Error("Debes iniciar sesión.");
    const db = load();
    const list = db[productId] || [];
    const isAdmin = (session.role === "admin");
    const email   = String(session.email||"").toLowerCase();

    const idx = list.findIndex(x => x.id === reviewId && (isAdmin || x.userEmail === email));
    if (idx === -1) throw new Error("No puedes borrar esta reseña.");
    list.splice(idx, 1);
    db[productId] = list;
    save(db);
    w.dispatchEvent(new CustomEvent("ms:reviews:updated", { detail: { productId }}));
    return true;
  }

  // Utilidades para UI
  function starsDisplay(rating) {
    const r = Number(rating||0);
    const full = Math.floor(r);
    const half = (r - full >= 0.5);
    return Array.from({length:5}).map((_,i)=>{
      if(i < full) return "★";
      if(i === full && half) return "☆";
      return "☆";
    }).join("");
  }

  w.Reviews = {
    getList, getStats, getMine, upsert, remove,
    starsDisplay, fmtDate
  };
})(window, document);
