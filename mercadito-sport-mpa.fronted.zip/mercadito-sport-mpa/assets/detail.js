// assets/detail.js — Quick View/Detalle + formulario de reseñas + carrito mínimo
(function () {
  "use strict";
  const $  = (s, r=document)=> r.querySelector(s);
  const $$ = (s, r=document)=> Array.from(r.querySelectorAll(s));
  const DATA = (window.PRODUCTS || []).slice();
  const fmt = n => new Intl.NumberFormat("es-CO",{style:"currency",currency:"COP"}).format(n);

  const Reviews = window.Reviews;
  const Auth = window.Auth;

  // ----- Drawer básico -----
  function ensureDrawer(){
    let drawer = $("#detailDrawer");
    if (drawer) return drawer;
    drawer = document.createElement("div");
    drawer.id = "detailDrawer";
    drawer.className = "drawer";
    drawer.setAttribute("aria-hidden", "true");
    drawer.innerHTML = `
      <div class="drawer-box">
        <div id="detailBox"></div>
      </div>
    `;
    document.body.appendChild(drawer);
    drawer.addEventListener("click", (e)=>{ if(e.target===drawer) closeDetail(); });
    document.addEventListener("keydown", (e)=>{ if(e.key==="Escape") closeDetail(); });
    return drawer;
  }

  function getById(id){ return DATA.find(p => String(p.id)===String(id)); }

  function priceBlock(p){
    const final = p.discount>0 ? Math.round(p.price*(1 - p.discount/100)) : p.price;
    const old   = p.discount>0 ? `<span class="old">${fmt(p.price)}</span>` : "";
    const badge = p.discount>0 ? `<span class="badge danger" style="margin-left:6px">-${p.discount}%</span>` : "";
    return `<div class="product-price"><span>${fmt(final)}</span>${old}${badge}</div>`;
  }

  function ratingStarsText(r=0){ return Reviews ? Reviews.starsDisplay(r) : ""; }

  function renderReviewsList(p){
    const wrap = $("#reviewsList");
    if(!wrap || !Reviews) return;
    const items = Reviews.getList(p.id);
    if(!items.length){
      wrap.innerHTML = `<div class="meta">Aún no hay reseñas.</div>`;
      return;
    }
    wrap.innerHTML = items.map(r=>`
      <div class="quote">
        <div><strong>${r.title || "Sin título"}</strong></div>
        <div style="margin-top:2px">${"★".repeat(r.rating)}${"☆".repeat(5-r.rating)}</div>
        <div class="meta" style="margin-top:4px">${r.userName || "Usuario"} · ${Reviews.fmtDate(r.date)}</div>
        ${r.body ? `<div style="margin-top:6px">${r.body}</div>` : ""}
        ${canEditDelete(r) ? `
          <div class="row" style="gap:8px;margin-top:8px">
            <button class="btn outline small btn-edit" data-id="${r.id}">Editar</button>
            <button class="btn outline small btn-del" data-id="${r.id}">Eliminar</button>
          </div>
        ` : ""}
      </div>
    `).join("");

    // Bind edición/borrado
    $$(".btn-edit", wrap).forEach(btn=>{
      btn.addEventListener("click", ()=>{
        const id = btn.getAttribute("data-id");
        const rev = items.find(x => x.id === id);
        if(!rev) return;
        // Prefill
        const s = Auth?.getSession?.();
        if(!s) return;
        $("#rvTitle").value = rev.title || "";
        $("#rvBody").value  = rev.body || "";
        setStarInput(rev.rating);
        $("#rvMode").textContent = "Actualizar reseña";
        $("#rvId").value = rev.id;
        $("#rvCancel").style.display = "inline-flex";
        $("#rvMsg").textContent = "Editando tu reseña (puedes guardar cambios).";
      });
    });
    $$(".btn-del", wrap).forEach(btn=>{
      btn.addEventListener("click", ()=>{
        const id = btn.getAttribute("data-id");
        const s = Auth?.getSession?.();
        try{
          Reviews.remove(p.id, id, s);
          renderAll(p);
        }catch(e){ alert(e.message); }
      });
    });
  }

  function canEditDelete(r){
    const s = Auth?.getSession?.();
    if(!s) return false;
    if(s.role === "admin") return true;
    return String(s.email||"").toLowerCase() === String(r.userEmail||"").toLowerCase();
    }

  function renderForm(p){
    const frm = $("#reviewForm");
    const section = $("#reviewsFormWrap");
    if(!frm || !section) return;

    const s = Auth?.getSession?.();
    if(!s){
      section.innerHTML = `
        <div class="card" style="box-shadow:none"><div class="pad">
          <div class="row" style="justify-content:space-between;align-items:center">
            <strong>Escribe una reseña</strong>
            <a class="btn small" href="./login.html">Iniciar sesión</a>
          </div>
          <p class="meta" style="margin-top:6px">Necesitas iniciar sesión para calificar y opinar.</p>
        </div></div>`;
      return;
    }

    // Si hay existente del usuario, prefilla
    const mine = Reviews?.getMine?.(p.id, s.email);
    if(mine){
      $("#rvTitle").value = mine.title || "";
      $("#rvBody").value  = mine.body  || "";
      setStarInput(mine.rating || 0);
      $("#rvId").value = mine.id;
      $("#rvMode").textContent = "Actualizar reseña";
      $("#rvCancel").style.display = "inline-flex";
      $("#rvMsg").textContent = "Puedes actualizar tu reseña.";
    } else {
      setStarInput(0);
      $("#rvId").value = "";
      $("#rvMode").textContent = "Publicar reseña";
      $("#rvCancel").style.display = "none";
      $("#rvMsg").textContent = "";
      $("#rvTitle").value = "";
      $("#rvBody").value = "";
    }

    // Submit
    frm.addEventListener("submit", (e)=>{
      e.preventDefault();
      try{
        const rating = getStarInput();
        const title  = $("#rvTitle").value.trim();
        const body   = $("#rvBody").value.trim();
        Reviews.upsert(p.id, { rating, title, body }, s);
        // Reset modo
        $("#rvId").value = "";
        $("#rvMode").textContent = "Publicar reseña";
        $("#rvCancel").style.display = "none";
        $("#rvMsg").textContent = "¡Gracias por tu reseña!";
        setStarInput(0);
        $("#rvTitle").value = "";
        $("#rvBody").value  = "";
        renderAll(p);
      }catch(err){
        $("#rvMsg").textContent = err.message || "No se pudo publicar.";
      }
    });

    $("#rvCancel").addEventListener("click", ()=>{
      $("#rvId").value = "";
      $("#rvMode").textContent = "Publicar reseña";
      $("#rvCancel").style.display = "none";
      $("#rvMsg").textContent = "";
      setStarInput(0);
      $("#rvTitle").value = "";
      $("#rvBody").value  = "";
    });

    // Estrellas (inputs)
    $$(".star-btn").forEach(btn=>{
      btn.addEventListener("mouseenter", ()=> paintStars(btn.dataset.val));
      btn.addEventListener("mouseleave", ()=> paintStars(getStarInput()));
      btn.addEventListener("click", ()=> setStarInput(Number(btn.dataset.val)));
    });
  }

  // ---- Control de estrellas (input) ----
  function setStarInput(val){
    const v = Math.max(0, Math.min(5, Number(val||0)));
    const hidden = $("#rvRating");
    if(hidden) hidden.value = String(v);
    paintStars(v);
  }
  function getStarInput(){
    return Math.max(0, Math.min(5, Number($("#rvRating")?.value || 0)));
  }
  function paintStars(v){
    $$(".star-btn").forEach((b, i)=>{
      b.classList.toggle("on", i < v);
    });
  }

  function priceWithStatsHeader(p){
    const stats = Reviews?.getStats?.(p.id) || {avg:p.rating||0,count:p.reviews||0};
    const avg = stats.count>0 ? stats.avg : (p.rating||0);
    const cnt = stats.count>0 ? stats.count : (p.reviews||0);
    return `
      <div class="row" style="gap:8px;align-items:center;margin:6px 0">
        <span class="stars-display">${ratingStarsText(avg)}</span>
        <span class="meta">· ${cnt} reseña${cnt!==1?"s":""}</span>
      </div>
      ${priceBlock(p)}
    `;
  }

  function renderAll(p){
    // Header precio + stats
    const headerStats = $("#detailStats");
    if(headerStats) headerStats.innerHTML = priceWithStatsHeader(p);
    // Lista reseñas
    renderReviewsList(p);
  }

  function renderDetail(p){
    const box = $("#detailBox");
    if(!box) return;

    const colors = (p.colors||[]).map(c=>`<span class="swatch" title="${c.name}" style="background:${c.hex}"></span>`).join("");
    const tags   = (p.tags||[]).map(t=>`<span class="badge">${t}</span>`).join(" ");

    box.innerHTML = `
      <div class="grid2">
        <div class="zoomable">
          <figure class="img"><img src="${p.image}" alt="${p.name}" style="width:100%;height:auto"/></figure>
        </div>
        <div>
          <div class="row" style="justify-content:space-between;align-items:center">
            <h3 style="margin:0">${p.name}</h3>
            <button class="btn outline small" id="detailClose">✕ Cerrar</button>
          </div>
          <div class="meta" style="margin-top:4px">${p.department} • ${p.sport} • ${p.brand}</div>
          <div id="detailStats"></div>
          <p class="meta" style="margin-top:8px">${p.description||""}</p>
          ${tags ? `<div class="row" style="gap:6px;margin-top:8px">${tags}</div>` : ""}
          ${colors ? `<div class="swatches" style="margin-top:8px">${colors}</div>` : ""}

          <div class="row" style="gap:8px;margin-top:12px">
            <input id="detailQty" type="number" min="1" value="1" class="pill" style="width:80px">
            <button class="btn" id="detailAdd">Agregar al carrito</button>
          </div>
          <div class="meta" style="margin-top:6px">Stock: ${p.stock ?? "—"}</div>

          <hr style="margin:14px 0;border:none;border-top:1px solid var(--border)">

          <div id="reviewsFormWrap">
            <form id="reviewForm" class="card" style="box-shadow:none"><div class="pad">
              <div class="row" style="justify-content:space-between;align-items:center">
                <strong id="rvMode">Publicar reseña</strong>
                <button type="button" id="rvCancel" class="btn outline small" style="display:none">Cancelar edición</button>
              </div>
              <input id="rvId" type="hidden">
              <input id="rvRating" type="hidden" value="0">
              <div class="stars-input" style="margin-top:8px">
                ${[1,2,3,4,5].map(v=> `<button type="button" class="star-btn" data-val="${v}" aria-label="${v} estrellas">★</button>`).join("")}
              </div>
              <div style="display:grid;gap:8px;margin-top:10px">
                <input id="rvTitle" class="input" placeholder="Título (opcional)">
                <textarea id="rvBody" class="input" rows="4" placeholder="Cuéntanos tu experiencia…"></textarea>
              </div>
              <div class="row" style="gap:8px;margin-top:10px">
                <button class="btn" type="submit">Guardar</button>
                <span id="rvMsg" class="meta"></span>
              </div>
            </div></form>
          </div>

          <strong style="display:block;margin:10px 0 6px">Reseñas</strong>
          <div id="reviewsList" class="testimonials" style="margin-top:8px"></div>
        </div>
      </div>
    `;

    $("#detailClose")?.addEventListener("click", closeDetail);
    $("#detailAdd")?.addEventListener("click", ()=>{
      const qty = Math.max(1, parseInt($("#detailQty").value,10) || 1);
      addToCart(p.id, qty);
      const btn = $("#detailAdd");
      btn.textContent = "Agregado ✓";
      setTimeout(()=> btn.textContent = "Agregar al carrito", 1200);
    });

    renderForm(p);
    renderAll(p);

    // Re-render cuando cambien reseñas (desde otras pestañas, etc.)
    window.addEventListener("ms:reviews:updated", (ev)=>{
      if(ev.detail?.productId === p.id) renderAll(p);
    }, { passive: true });
  }

  // ----- Carrito mínimo -----
  const CART_KEY = "ms_cart";
  function getCart(){
    try { return JSON.parse(localStorage.getItem(CART_KEY) || "{}"); }
    catch { return {}; }
  }
  function setCart(c){ localStorage.setItem(CART_KEY, JSON.stringify(c || {})); }
  function addToCart(id, qty=1){
    const c = getCart();
    c[id] = (c[id] || 0) + qty;
    setCart(c);
    window.dispatchEvent(new CustomEvent("ms:cart:updated", { detail: c }));
  }
  if (typeof window.addToCart !== "function") window.addToCart = addToCart;

  // ----- API global -----
  function openDetail(id){
    const p = getById(id);
    if(!p){ alert("Producto no encontrado."); return; }
    const drawer = ensureDrawer();
    renderDetail(p);
    drawer.classList.add("open");
    drawer.setAttribute("aria-hidden", "false");
  }
  function closeDetail(){
    const drawer = $("#detailDrawer");
    if(!drawer) return;
    drawer.classList.remove("open");
    drawer.setAttribute("aria-hidden", "true");
  }

  window.openDetail  = openDetail;
  window.closeDetail = closeDetail;
})();
