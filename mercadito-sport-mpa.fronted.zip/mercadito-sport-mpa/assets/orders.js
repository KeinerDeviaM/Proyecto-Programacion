// assets/orders.js — Historial de pedidos con filtro de sesión (admin ve todo)
(function () {
  const $  = (s, r=document)=> r.querySelector(s);
  const $$ = (s, r=document)=> Array.from(r.querySelectorAll(s));
  const S  = window.MSStore;

  const list = $("#ordersList");
  const empty = $("#emptyOrders");
  const btnCreateFromCart = $("#createFromCart");

  function loadOrders(){
    try { return JSON.parse(localStorage.getItem("ms_orders")||"[]"); }
    catch { return []; }
  }
  function fmt(n){ return S ? S.fmt(n) : new Intl.NumberFormat("es-CO",{style:"currency",currency:"COP"}).format(n||0); }
  function fmtDate(iso){ const d = new Date(iso); return d.toLocaleString(); }

  function itemsTableHTML(items){
    return `
      <table class="table">
        <thead><tr><th>Producto</th><th>Cant.</th><th>Unitario</th><th>Total</th></tr></thead>
        <tbody>
          ${items.map(it => `
            <tr>
              <td><div style="font-weight:600">${it.name || it.id}</div><div class="mini">ID: ${it.id}</div></td>
              <td>${it.qty}</td>
              <td>${fmt(it.unitPrice||0)}</td>
              <td><strong>${fmt(it.lineTotal||((it.unitPrice||0)*(it.qty||0)))}</strong></td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    `;
  }

  function cardHTML(o){
    const itemsCount = (o.items||[]).reduce((a,b)=> a + (b.qty||0), 0);
    return `
      <article class="card order-card" data-id="${o.id}">
        <div class="pad">
          <div class="head" style="display:flex;justify-content:space-between;align-items:center;gap:10px">
            <div>
              <div style="font-weight:800">Pedido ${o.id}</div>
              <div class="order-meta" style="display:flex;gap:12px;flex-wrap:wrap;font-size:12px;color:var(--muted)">
                <span>Fecha: ${fmtDate(o.date)}</span>
                <span>Artículos: ${itemsCount}</span>
                <span>Total: <strong>${fmt(o.totals?.total||0)}</strong></span>
                <span>Estado: <span class="badge">${o.status||"pagado"}</span></span>
              </div>
            </div>
            <div class="row" style="gap:8px">
              <button class="btn outline small toggle">Ver detalle</button>
              <a class="btn small" href="./checkout.html">Comprar de nuevo</a>
            </div>
          </div>
          <div class="order-body" style="display:none;margin-top:8px">
            ${itemsTableHTML(o.items||[])}
          </div>
        </div>
      </article>
    `;
  }

  function render(){
    const ordersAll = loadOrders();
    const s = (window.Auth && Auth.getSession && Auth.getSession()) || null;

    let orders = ordersAll;
    if (s && s.role !== "admin") {
      orders = ordersAll.filter(o =>
        (o.userEmail && o.userEmail === s.email) ||
        (o.customer && o.customer.email && o.customer.email === s.email)
      );
    }

    if (!orders.length) {
      empty.style.display = "block";
      list.innerHTML = "";
      const hasCart = (window.MSStore && MSStore.cartItems().length > 0);
      if (btnCreateFromCart) btnCreateFromCart.style.display = hasCart ? "inline-flex" : "none";
      return;
    }

    empty.style.display = "none";
    list.innerHTML = orders.map(cardHTML).join("");

    $$(".order-card .toggle", list).forEach(btn => {
      btn.addEventListener("click", (e)=>{
        const card = e.currentTarget.closest(".order-card");
        const body = card.querySelector(".order-body");
        body.style.display = body.style.display === "none" ? "block" : "none";
      });
    });
  }

  // Botón demo (opcional): crear pedido desde carrito si no hay
  btnCreateFromCart?.addEventListener("click", ()=>{
    if(!window.MSStore){ alert("Carrito no disponible."); return; }
    const items = MSStore.cartItems();
    if(!items.length){ alert("Tu carrito está vacío."); return; }
    const t = MSStore.totals();
    const order = {
      id: MSStore.genOrderId(),
      date: new Date().toISOString(),
      items: items.map(it=>({ id: it.id, name: it.name, qty: it.qty, unitPrice: it.unitPrice, lineTotal: it.lineTotal })),
      totals: t,
      status: "pagado",
      userEmail: (window.Auth && Auth.getSession && Auth.getSession()?.email) || null
    };
    try {
      const arr = JSON.parse(localStorage.getItem("ms_orders") || "[]");
      arr.unshift(order);
      localStorage.setItem("ms_orders", JSON.stringify(arr));
    } catch(e){}
    render();
    alert("Pedido demo creado desde tu carrito.");
  });

  render();
})();
