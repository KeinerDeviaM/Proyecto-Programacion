// assets/checkout.js — pago + factura (no vacía carrito; asocia usuario si hay sesión)
(function () {
  const $  = (s, r=document)=> r.querySelector(s);
  const S  = window.MSStore;

  if(!S){ console.warn("MSStore no encontrado."); return; }

  const itemsBox = $("#orderItems");
  const subEl = $("#sub"), shipEl = $("#ship"), taxEl = $("#tax"), totalEl = $("#total");

  function lineHTML(it){
    return `
      <div class="row" style="gap:8px; align-items:center">
        <div class="img" style="width:56px;height:56px;overflow:hidden;border-radius:10px">
          <img src="${it.image}" alt="${it.name}" style="width:100%;height:100%;object-fit:cover">
        </div>
        <div style="flex:1">
          <div style="font-weight:600">${it.name}</div>
          <div class="meta">${it.brand} • ${it.sport}</div>
          <div class="meta">x${it.qty} • ${S.fmt(it.unitPrice)}</div>
        </div>
        <div><strong>${S.fmt(it.lineTotal)}</strong></div>
      </div>
    `;
  }
  function renderSummary(){
    const items = S.cartItems();
    itemsBox.innerHTML = items.map(lineHTML).join("") || `<div class="meta">No hay artículos. <a href="./carrito.html">Volver al carrito</a></div>`;
    const t = S.totals();
    subEl.textContent   = S.fmt(t.sub);
    shipEl.textContent  = S.fmt(t.ship);
    taxEl.textContent   = S.fmt(t.tax);
    totalEl.textContent = S.fmt(t.total);
  }

  // Validaciones básicas
  const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const expRe   = /^(0[1-9]|1[0-2])\/\d{2}$/;
  const cardRe  = /^[0-9 ]{12,19}$/;
  const cvvRe   = /^\d{3,4}$/;

  $("#confirmar")?.addEventListener("click", ()=>{
    const items = S.cartItems();
    if(items.length === 0){ alert("Tu carrito está vacío."); location.href="./carrito.html"; return; }

    const data = {
      firstName: $("#firstName").value.trim(), lastName : $("#lastName").value.trim(),
      email    : $("#email").value.trim(),    phone    : $("#phone").value.trim(),
      address  : $("#address").value.trim(),  city     : $("#city").value.trim(),
      state    : $("#state").value.trim(),    zip      : $("#zip").value.trim(),
      doc      : $("#doc").value.trim(),
      cardNumber: $("#cardNumber").value.trim(), cardName: $("#cardName").value.trim(),
      cardExp: $("#cardExp").value.trim(),       cardCvv: $("#cardCvv").value.trim(),
      terms: $("#terms").checked
    };

    if(!data.firstName || !data.lastName || !data.email || !data.phone || !data.address || !data.city || !data.state || !data.zip){ alert("Completa todos los campos de envío."); return; }
    if(!emailRe.test(data.email)){ alert("Email inválido."); return; }
    if(!cardRe.test(data.cardNumber.replace(/\s+/g,''))){ alert("Número de tarjeta inválido (demo)."); return; }
    if(!expRe.test(data.cardExp)){ alert("Expiración inválida (usa MM/AA)."); return; }
    if(!cvvRe.test(data.cardCvv)){ alert("CVV inválido."); return; }
    if(!data.terms){ alert("Debes aceptar los términos y condiciones."); return; }

    const t = S.totals(); const orderId = S.genOrderId(); const now = new Date();
    const session = (window.Auth && Auth.getSession && Auth.getSession()) || null;

    setTimeout(()=>{
      // Construir orden
      const order = {
        id: orderId,
        date: now.toISOString(),
        items: items.map(it => ({
          id: it.id, name: it.name, qty: it.qty, unitPrice: it.unitPrice, lineTotal: it.lineTotal
        })),
        totals: t,
        customer: {
          firstName: data.firstName, lastName: data.lastName, email: data.email,
          phone: data.phone, address: data.address, city: data.city, state: data.state, zip: data.zip, doc: data.doc
        },
        userEmail: session?.email || data.email,   // ← vínculo con usuario
        userRole:  session?.role  || "guest",
        status: "pagado"
      };

      // Persistir
      try {
        const arr = JSON.parse(localStorage.getItem("ms_orders") || "[]");
        arr.unshift(order);
        localStorage.setItem("ms_orders", JSON.stringify(arr));
        localStorage.setItem("ms_last_order", JSON.stringify(order));
      } catch(e){ console.warn("No se pudo guardar el historial", e); }

      // Factura
      const inv = `
        <div class="row" style="justify-content:space-between;align-items:flex-start">
          <div>
            <div class="title">Factura</div>
            <div class="meta">Pedido: <strong>${orderId}</strong></div>
            <div class="meta">Fecha: ${now.toLocaleString()}</div>
          </div>
          <div class="meta">Mercadito Sport<br/>Soporte: ayuda@mercadito.test</div>
        </div>
        <hr style="border:none;border-top:1px solid var(--border); margin:10px 0"/>
        <div class="row" style="gap:20px; align-items:flex-start; flex-wrap:wrap">
          <div>
            <strong>Enviado a:</strong><br/>
            ${data.firstName} ${data.lastName}<br/>
            ${data.address}<br/>
            ${data.city}, ${data.state}, ${data.zip}<br/>
            ${data.phone} • ${data.email}
          </div>
          <div>
            <strong>Método de pago:</strong><br/>
            Tarjeta terminada en •••• ${data.cardNumber.slice(-4)}<br/>
            Exp: ${data.cardExp}
          </div>
        </div>
        <div class="divider"></div>
        <table class="table">
          <thead><tr><th>Producto</th><th>Cant.</th><th>Unitario</th><th>Total</th></tr></thead>
          <tbody>
            ${items.map(it=>`
              <tr>
                <td>${it.name}</td>
                <td>${it.qty}</td>
                <td>${S.fmt(it.unitPrice)}</td>
                <td><strong>${S.fmt(it.lineTotal)}</strong></td>
              </tr>
            `).join("")}
          </tbody>
          <tfoot>
            <tr><td colspan="3" style="text-align:right" class="meta">Subtotal</td><td><strong>${S.fmt(t.sub)}</strong></td></tr>
            <tr><td colspan="3" style="text-align:right" class="meta">Envío</td><td><strong>${S.fmt(t.ship)}</strong></td></tr>
            <tr><td colspan="3" style="text-align:right" class="meta">IVA (estimado 19%)</td><td><strong>${S.fmt(t.tax)}</strong></td></tr>
            <tr><td colspan="3" style="text-align:right"><strong>Total</strong></td><td><strong style="font-size:16px">${S.fmt(t.total)}</strong></td></tr>
          </tfoot>
        </table>
        <div class="row" style="gap:8px; margin-top:10px">
          <a class="btn" href="#" id="printInv">Imprimir / Guardar PDF</a>
          <a class="btn outline" href="./orders.html">Ver mis pedidos</a>
        </div>
      `;
      const box = document.getElementById("invoiceBox");
      const cont = document.getElementById("invoiceContent");
      if (box && cont) { cont.innerHTML = inv; box.style.display = "block"; }
      document.getElementById("printInv")?.addEventListener("click", (e)=>{ e.preventDefault(); window.print(); });

      // NO vaciar carrito automáticamente (si quieres, activa):
      // S.clearCart();

      window.scrollTo({ top: 0, behavior: "smooth" });
      alert("¡Pago confirmado! Tu pedido quedó guardado en Mis pedidos.");
      renderSummary();
    }, 400);
  });

  renderSummary();
})();
