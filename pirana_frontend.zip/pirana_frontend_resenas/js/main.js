(() => {
  const CART_KEY="pirana_cart", SHIPPING_KEY="pirana_shipping", PRODUCTS_KEY="pirana_products_v2", PURCHASES_KEY="pirana_purchases", SALES_KEY="pirana_sales", REVIEWS_KEY="pirana_reviews"; 
  const TAX_RATE=.075;
  const fmt=n=>`$${Number(n||0).toFixed(2)}`;

  // --- Cart ---
  const getCart=()=>{try{return JSON.parse(localStorage.getItem(CART_KEY))||[]}catch{return[]}};
  const saveCart=it=>{localStorage.setItem(CART_KEY,JSON.stringify(it));updateCartCount()};
  const clearCart=()=>saveCart([]);
  const getShipping=()=>Number(localStorage.getItem(SHIPPING_KEY)||0), setShipping=v=>localStorage.setItem(SHIPPING_KEY,String(v));
  const updateCartCount=()=>{const c=getCart().reduce((a,i)=>a+(i.qty||0),0);document.querySelectorAll('a.btn--primary[href$="cart.html"]').forEach(a=>{let b=a.querySelector(".cart-count"); if(!b){b=document.createElement("span"); b.className="cart-count"; a.appendChild(b);} b.textContent=String(c); b.style.display=c>0?"inline-block":"none";})};
  const addToCart=item=>{const cart=getCart(); const key=`${item.sku}|${item.color||""}|${item.size||""}`; const ex=cart.find(i=>`${i.sku}|${i.color||""}|${i.size||""}`===key); if(ex) ex.qty+=item.qty||1; else cart.push({...item,qty:item.qty||1}); saveCart(cart)};
  const calcSubtotal=()=>getCart().reduce((a,i)=>a+i.price*i.qty,0);
  const renderSummary=()=>{const s=calcSubtotal(), sh=getShipping(), t=s*TAX_RATE, tt=s+sh+t; 
    const sub=document.getElementById("summary-subtotal"), ship=document.getElementById("summary-shipping"), tax=document.getElementById("summary-tax"), total=document.getElementById("summary-total"); 
    if(sub)sub.textContent=fmt(s); if(ship)ship.textContent=sh===0?"Gratis":fmt(sh); if(tax)tax.textContent=fmt(t); if(total)total.textContent=fmt(tt)};
  const renderCart=()=>{const list=document.getElementById("cart-list"); if(!list)return; const cart=getCart(); list.innerHTML=""; 
    if(cart.length===0){list.innerHTML=`<p class="muted">Tu carrito está vacío. <a href="catalog.html" style="color:#fff;font-weight:800;text-decoration:underline">Ir al catálogo</a></p>`}
    cart.forEach((p,idx)=>{const row=document.createElement("div"); row.className="summary"; row.innerHTML=
      `<div class="row" style="justify-content:space-between">
        <div class="row">
          <img src="${p.image}" alt="${p.name}" style="width:66px;height:66px;object-fit:cover;border-radius:8px;border:1px solid var(--chip-border)">
          <div><div><strong>${p.name}</strong></div><div class="muted">${p.color||""}${p.size? " · Talla "+p.size:""}</div><div class="muted">${fmt(p.price)} c/u</div></div>
        </div>
        <div class="row">
          <button class="btn btn--ghost" data-action="minus" data-idx="${idx}">−</button>
          <span>${p.qty}</span>
          <button class="btn btn--ghost" data-action="plus" data-idx="${idx}">+</button>
          <button class="btn btn--ghost" data-action="remove" data-idx="${idx}">✕</button>
        </div>
      </div>`; list.appendChild(row)});
    list.addEventListener("click",e=>{const b=e.target.closest("button[data-action]"); if(!b)return; const cart=getCart(); const i=Number(b.dataset.idx); if(!cart[i])return; 
      if(b.dataset.action==="plus")cart[i].qty+=1;
      if(b.dataset.action==="minus")cart[i].qty=Math.max(1,cart[i].qty-1);
      if(b.dataset.action==="remove")cart.splice(i,1);
      saveCart(cart); renderCart(); renderSummary();
    });
  };
  const bindShippingPage=()=>{const r=document.querySelectorAll('input[name="shipping"]'); if(!r.length)return; const cur=getShipping(); 
    r.forEach(x=>{if(x.value==="express"&&cur===10)x.checked=true; if(x.value==="standard"&&cur===0)x.checked=true; x.addEventListener("change",()=>setShipping(x.value==="express"?10:0))}); 
    renderSummary();
  };
  const bindPaymentPage=()=>{const btn=document.querySelector('a[href="success.html"]'); if(!btn){renderSummary(); return;} renderSummary(); btn.addEventListener("click",()=>localStorage.setItem("pirana_clear_cart_on_success","1"))};

  // --- Products (v2) ---
  const DEFAULT=[
    {sku:"M-CALZ-001",section:"men",category:"calzado",name:"Runner Pro M",price:150,image:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=1200&auto=format&fit=crop",isNew:true,salePct:15},
    {sku:"M-CAMI-002",section:"men",category:"camisas",name:"Camiseta DryFit M",price:35,image:"https://images.unsplash.com/photo-1620799139634-1749d9373b3a?q=80&w=1200&auto=format&fit=crop",isNew:false,salePct:0},
    {sku:"M-PANT-003",section:"men",category:"pantalones",name:"Short Training M",price:40,image:"https://images.unsplash.com/photo-1541099649105-f69ad21f3246?q=80&w=1200&auto=format&fit=crop",isNew:false,salePct:10},
    {sku:"M-ACCE-004",section:"men",category:"accesorios",name:"Gorra Pro",price:22,image:"https://images.unsplash.com/photo-1520975682031-b71f4e68b0d8?q=80&w=1200&auto=format&fit=crop",isNew:false,salePct:0},
    {sku:"W-CALZ-001",section:"women",category:"calzado",name:"Runner Air W",price:145,image:"https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=1200&auto=format&fit=crop",isNew:true,salePct:20},
    {sku:"W-CAMI-002",section:"women",category:"camisas",name:"Top Compresión W",price:30,image:"https://images.unsplash.com/photo-1539185441755-769473a23570?q=80&w=1200&auto=format&fit=crop",isNew:false,salePct:0},
    {sku:"W-PANT-003",section:"women",category:"pantalones",name:"Leggings Balance",price:60,image:"https://images.unsplash.com/photo-1540206276207-3af25c08abc4?q=80&w=1200&auto=format&fit=crop",isNew:false,salePct:0},
    {sku:"W-ACCE-004",section:"women",category:"accesorios",name:"Bandas Elásticas",price:18,image:"https://images.unsplash.com/photo-1520975682031-b71f4e68b0d8?q=80&w=1200&auto=format&fit=crop",isNew:false,salePct:0},
    {sku:"Y-ACCE-001",section:"yoga",category:"accesorios",name:"Mat Antideslizante",price:25,image:"https://images.unsplash.com/photo-1540206276207-3af25c08abc4?q=80&w=1200&auto=format&fit=crop",isNew:false,salePct:15},
    {sku:"Y-CAMI-002",section:"yoga",category:"camisas",name:"Camiseta Breath",price:28,image:"https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=1200&auto=format&fit=crop",isNew:true,salePct:0},
    {sku:"Y-PANT-003",section:"yoga",category:"pantalones",name:"Pantalón Suave Yoga",price:42,image:"https://images.unsplash.com/photo-1593032457869-9f6ccc3dc80b?q=80&w=1200&auto=format&fit=crop",isNew:false,salePct:0},
    {sku:"J-CALZ-001",section:"junior",category:"calzado",name:"Runner Kids",price:90,image:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=1200&auto=format&fit=crop",isNew:false,salePct:10},
    {sku:"J-CAMI-002",section:"junior",category:"camisas",name:"Camiseta Kids",price:22,image:"https://images.unsplash.com/photo-1620799139634-1749d9373b3a?q=80&w=1200&auto=format&fit=crop",isNew:true,salePct:0},
    {sku:"J-PANT-003",section:"junior",category:"pantalones",name:"Short Kids",price:25,image:"https://images.unsplash.com/photo-1541099649105-f69ad21f3246?q=80&w=1200&auto=format&fit=crop",isNew:false,salePct:0},
    {sku:"J-ACCE-004",section:"junior",category:"accesorios",name:"Mochila School",price:35,image:"https://images.unsplash.com/photo-1540206276207-3af25c08abc4?q=80&w=1200&auto=format&fit=crop",isNew:false,salePct:0},
  ];
  const labelSection={men:"Hombre",women:"Mujer",yoga:"Yoga",junior:"Junior"},
        labelCategory={calzado:"Calzado",pantalones:"Pantalones/Pantalonetas",camisas:"Camisas/Camisetas",accesorios:"Accesorios"};
  const getProducts=()=>{try{const raw=localStorage.getItem(PRODUCTS_KEY); if(!raw) return [...DEFAULT]; return JSON.parse(raw);}catch{return[...DEFAULT]}};
  const saveProducts=arr=>localStorage.setItem(PRODUCTS_KEY,JSON.stringify(arr));
  const allProducts=()=>getProducts();
  const getProductBySKU=sku=>allProducts().find(p=>p.sku===sku);

  // --- Catalog (sec/type/filter) ---
  const getParam=n=>new URL(location.href).searchParams.get(n);
  function buildFilterLinks(sec){
    const row=document.getElementById("subfilters"); if(!row) return;
    const make=(label,params,primary=false)=>{
      const url=new URL(location.href);
      if(sec) url.searchParams.set("sec",sec); else url.searchParams.delete("sec");
      Object.keys(params).forEach(k=>params[k]===null?url.searchParams.delete(k):url.searchParams.set(k,params[k]));
      const a=document.createElement("a"); a.className="chip"+(primary?" chip--primary":""); a.href=url.pathname+"?"+url.searchParams.toString(); a.textContent=label; row.appendChild(a);
    };
    row.innerHTML=""; 
    make("Todo",{type:"all",filter:null},true);
    make("Calzado",{type:"calzado",filter:null});
    make("Pantalones/Pantalonetas",{type:"pantalones",filter:null});
    make("Camisas/Camisetas",{type:"camisas",filter:null});
    make("Accesorios",{type:"accesorios",filter:null});
    make("Ofertas",{type:null,filter:"offers"});
    make("Novedades",{type:null,filter:"new"});
  }
  function renderCatalog(){
    const grid=document.getElementById("catalog-grid"); if(!grid) return;
    const title=document.getElementById("catalog-title");
    const sec=(getParam("sec")||"").toLowerCase();
    const type=(getParam("type")||"all").toLowerCase();
    const filter=(getParam("filter")||"").toLowerCase();
    buildFilterLinks(sec);

    let items=allProducts();
    if(sec) items=items.filter(p=>p.section===sec);
    if(type && type!=="all") items=items.filter(p=>p.category===type);
    if(filter==="offers") items=items.filter(p=>(p.salePct||0)>0);
    if(filter==="new") items=items.filter(p=>!!p.isNew);

    const heading=sec?(labelSection[sec]||"Catálogo"):"Todos";
    title.textContent=filter==="offers"?"Ofertas":(filter==="new"?"Novedades":heading);

    grid.innerHTML="";
    items.forEach(item=>{
      const sale=(item.salePct||0)>0;
      const final=sale?(item.price*(1-item.salePct/100)):item.price;
      const a=document.createElement("a");
      a.className="product-card";
      a.href=`product.html?sku=${encodeURIComponent(item.sku)}`;
      a.innerHTML = `
        <img class="product-card__img" src="${item.image}" alt="${item.name}">
        <div class="product-card__body">
          <div>
            <div class="card__title">${item.name}</div>
            <div class="muted" style="font-size:.9rem">${labelSection[item.section]} · ${labelCategory[item.category]}</div>
          </div>
          <div class="price">${sale?`<s>${fmt(item.price)}</s> ${fmt(final)}`:fmt(item.price)}</div>
        </div>
        ${item.isNew?`<span class="badge badge--new" style="position:absolute;top:8px;left:8px">Nuevo</span>`:""}
        ${sale?`<span class="badge badge--sale" style="position:absolute;top:8px;right:8px">-${item.salePct}%</span>`:""}
      `;
      grid.appendChild(a);
    });
    if(items.length===0){
      const empty=document.createElement("div"); empty.className="summary";
      empty.innerHTML="<strong>No hay productos para esta combinación.</strong> <div class='muted'>Prueba con <em>Todo</em> u otra categoría.</div>";
      grid.appendChild(empty);
    }
  }

  // --- Admin ---
  function bindAdminPage(){ 
    if(!location.pathname.endsWith("admin.html")) return;
    const tb=document.querySelector("#products-table tbody"),
          form=document.getElementById("product-form"),
          sku=document.getElementById("p-sku"), name=document.getElementById("p-name"),
          price=document.getElementById("p-price"), image=document.getElementById("p-image"),
          section=document.getElementById("p-section"), category=document.getElementById("p-category"),
          salePct=document.getElementById("p-sale"), isNew=document.getElementById("p-new"),
          btnClear=document.getElementById("btn-clear"),
          btnExport=document.getElementById("btn-export"),
          btnImport=document.getElementById("btn-import"),
          btnReset=document.getElementById("btn-reset"),
          boxImp=document.getElementById("import-box"),
          boxExp=document.getElementById("export-box"),
          impText=document.getElementById("import-text"),
          expText=document.getElementById("export-text");

    const fill=()=>{const arr=allProducts(); tb.innerHTML = arr.map(p=>`
      <tr>
        <td><code>${p.sku}</code></td><td>${p.name}</td><td>${fmt(p.price)}</td>
        <td>${(p.salePct||0)>0?`<span class="badge badge--sale">-${p.salePct}%</span>`:"-"}</td>
        <td>${p.isNew?`<span class="badge badge--new">Nuevo</span>`:"-"}</td>
        <td>${p.section}</td><td>${p.category}</td>
        <td><a href="${p.image}" target="_blank" rel="noopener">Ver</a></td>
        <td><div class="row row-right">
          <button class="btn btn--ghost btn-sm" data-action="edit" data-sku="${p.sku}">Editar</button>
          <button class="btn btn--ghost btn-sm" data-action="delete" data-sku="${p.sku}">Eliminar</button>
        </div></td>
      </tr>`).join("") || `<tr><td colspan="9" class="muted">Sin productos.</td></tr>`;};
    fill();

    form.addEventListener("submit",e=>{e.preventDefault();
      const arr=allProducts(); 
      const item={sku:sku.value.trim(),name:name.value.trim(),price:Number(price.value),image:image.value.trim(),section:section.value,category:category.value,salePct:Number(salePct.value||0),isNew:isNew.checked};
      if(!item.sku||!item.name||!item.image||isNaN(item.price)){alert("Campos incompletos");return;}
      const i=arr.findIndex(x=>x.sku===item.sku); if(i>=0)arr[i]=item; else arr.push(item);
      saveProducts(arr); fill(); form.reset(); alert("Producto guardado");
    });
    btnClear.addEventListener("click",()=>form.reset());
    tb.addEventListener("click",e=>{
      const b=e.target.closest("button[data-action]"); if(!b) return;
      const id=b.dataset.sku, arr=allProducts();
      if(b.dataset.action==="edit"){
        const f=arr.find(x=>x.sku===id); if(!f)return;
        sku.value=f.sku; name.value=f.name; price.value=f.price; image.value=f.image; section.value=f.section; category.value=f.category; salePct.value=f.salePct||0; isNew.checked=!!f.isNew;
        window.scrollTo({top:0,behavior:"smooth"});
      }
      if(b.dataset.action==="delete"){
        if(confirm("¿Eliminar?")){const i=arr.findIndex(x=>x.sku===id); if(i>=0){arr.splice(i,1); saveProducts(arr); fill();}}
      }
    });
    btnExport.addEventListener("click",()=>{expText.value=JSON.stringify(allProducts(),null,2); boxExp.style.display="block"; boxImp.style.display="none";});
    document.getElementById("export-close").addEventListener("click",()=>boxExp.style.display="none");
    btnImport.addEventListener("click",()=>{impText.value=""; boxImp.style.display="block"; boxExp.style.display="none";});
    document.getElementById("import-apply").addEventListener("click",()=>{ try{const data=JSON.parse(impText.value); if(!Array.isArray(data)) throw new Error("Array"); saveProducts(data); boxImp.style.display="none"; fill(); alert("Importado"); }catch(e){ alert("JSON inválido"); }});
    document.getElementById("import-cancel").addEventListener("click",()=>boxImp.style.display="none");
    btnReset.addEventListener("click",()=>{ if(confirm("¿Restablecer catálogo por defecto?")){ localStorage.removeItem(PRODUCTS_KEY); fill(); }});
  };

  // --- Purchases & Reviews ---
  const getPurchases=()=>{try{return JSON.parse(localStorage.getItem(PURCHASES_KEY))||[]}catch{return[]}}, 
        addPurchaseSKU=sku=>{const set=new Set(getPurchases()); set.add(sku); localStorage.setItem(PURCHASES_KEY,JSON.stringify([...set]))},
        hasPurchased=sku=>new Set(getPurchases()).has(sku);
  const getSales=()=>{try{return JSON.parse(localStorage.getItem(SALES_KEY))||{}}catch{return{}}},
        incrementSales=(sku,qty)=>{const s=getSales(); s[sku]=(s[sku]||0)+(qty||1); localStorage.setItem(SALES_KEY,JSON.stringify(s))},
        getSalesCount=sku=>{const s=getSales(); return s[sku]||0};
  const getReviews=sku=>{try{const all=JSON.parse(localStorage.getItem(REVIEWS_KEY))||{}; return Array.isArray(all[sku])?all[sku]:[]}catch{return[]}},
        saveReviews=(sku,arr)=>{const all=JSON.parse(localStorage.getItem(REVIEWS_KEY))||{}; all[sku]=arr; localStorage.setItem(REVIEWS_KEY,JSON.stringify(all))},
        addReview=(sku,rev)=>{const arr=getReviews(sku); arr.unshift(rev); saveReviews(sku,arr)},
        averageRating=sku=>{const a=getReviews(sku); if(!a.length) return 0; return a.reduce((x,r)=>x+(r.rating||0),0)/a.length};
  const renderStars=(el,val)=>{if(!el)return; const v=Math.round(val); el.innerHTML=""; for(let i=1;i<=5;i++){const s=document.createElement("span"); s.className="star"+(i<=v?" active":""); s.textContent="★"; el.appendChild(s);}};
  const renderStarInput=(el,cur=0)=>{if(!el)return; el.innerHTML=""; for(let i=1;i<=5;i++){const s=document.createElement("span"); s.className="star input"+(i<=cur?" active":""); s.textContent="★"; s.dataset.value=String(i); el.appendChild(s);}};

  // --- Product page ---
  function hydrateProductPageFromSKU(){ if(!location.pathname.endsWith("product.html"))return; 
    const sku=new URL(location.href).searchParams.get("sku"); if(!sku)return; const p=getProductBySKU(sku); if(!p)return;
    document.querySelector("h1.h1").textContent=p.name;
    document.querySelector(".gallery img").src=p.image;
    const priceEl=document.querySelector(".price");
    const sale=(p.salePct||0)>0; const final=sale?(p.price*(1-(p.salePct/100))):p.price;
    priceEl.innerHTML=sale?`<s>${fmt(p.price)}</s> ${fmt(final)}`:fmt(p.price);
    document.getElementById("add-to-cart").dataset.sku=p.sku;
  }
  function bindProductPageOptions(){
    const add=document.getElementById("add-to-cart"); if(!add)return;
    document.querySelectorAll(".pills").forEach(g=>{g.addEventListener("click",e=>{const pill=e.target.closest(".pill"); if(!pill) return; g.querySelectorAll(".pill").forEach(p=>p.classList.remove("active")); pill.classList.add("active");});});
    add.addEventListener("click",e=>{
      e.preventDefault();
      const name=document.querySelector("h1.h1")?.textContent?.trim()||"Producto";
      const price=Number((document.querySelector(".price")?.textContent||"$0").replace(/[^0-9.]/g,""))||0;
      const image=document.querySelector(".gallery img")?.src||"";
      const color=document.querySelector('[data-group="color"] .pill.active')?.textContent?.trim()||"";
      const size=document.querySelector('[data-group="size"] .pill.active')?.textContent?.trim()||"";
      const sku=add.dataset.sku||"SKU-DEMO";
      addToCart({sku,name,price,image,color,size,qty:1});
      add.textContent="Añadido ✓"; setTimeout(()=>add.textContent="Añadir al carrito",900);
    });
  }
  function bindProductReviews(){
    if(!location.pathname.endsWith("product.html")) return;
    const add=document.getElementById("add-to-cart");
    const sku=add?.dataset?.sku || new URL(location.href).searchParams.get("sku");
    const sold=document.getElementById("sold-count"), stars=document.getElementById("rating-stars"), count=document.getElementById("reviews-count");
    renderStars(stars,averageRating(sku));
    if(count){const c=getReviews(sku).length; count.textContent=`(${c} reseña${c!==1?'s':''})`;}
    if(sold) sold.textContent=String(getSalesCount(sku));

    const list=document.getElementById("reviews-list");
    const renderList=()=>{list.innerHTML=""; getReviews(sku).forEach(r=>{const item=document.createElement("div"); item.className="review";
      const meta=document.createElement("div"); meta.className="meta"; const starBox=document.createElement("div"); starBox.className="stars"; renderStars(starBox,r.rating);
      const who=document.createElement("span"); who.textContent=r.name||"Anónimo"; const when=document.createElement("span"); when.textContent=new Date(r.date).toLocaleDateString();
      meta.appendChild(starBox); meta.appendChild(document.createTextNode(" • ")); meta.appendChild(who); meta.appendChild(document.createTextNode(" • ")); meta.appendChild(when);
      const txt=document.createElement("div"); txt.className="text"; txt.textContent=r.text; item.appendChild(meta); item.appendChild(txt); list.appendChild(item);});
      renderStars(stars,averageRating(sku)); if(count){const c=getReviews(sku).length; count.textContent=`(${c} reseña${c!==1?'s':''})`;}
    };
    renderList();

    const form=document.getElementById("review-form"), notice=document.getElementById("review-notice"), nameI=document.getElementById("review-name"), textI=document.getElementById("review-text"), ratingI=document.getElementById("rating-input");
    let sel=0; renderStarInput(ratingI,sel);
    ratingI.addEventListener("click",e=>{const star=e.target.closest(".star.input"); if(!star) return; sel=Number(star.dataset.value); renderStarInput(ratingI,sel);});
    if(!hasPurchased(sku)){form.style.display="none"; notice.style.display="block"; notice.textContent="Solo los clientes que compraron este producto pueden dejar una reseña (verificado).";}
    else { form.style.display="block"; notice.style.display="none"; }
    form?.addEventListener("submit",e=>{e.preventDefault(); if(sel<1||sel>5){alert("Selecciona de 1 a 5 estrellas");return;} const text=(textI.value||"").trim(); if(!text){alert("Escribe tu reseña"); return;}
      addReview(sku,{id:Date.now(),name:(nameI.value||"").trim()||"Anónimo",rating:sel,text,date:new Date().toISOString()});
      nameI.value=""; textI.value=""; sel=0; renderStarInput(ratingI,0); renderList(); alert("¡Gracias por tu reseña!");
    });
  }
  function bindSuccessSalesAndPurchases(){ if(!location.pathname.endsWith("success.html")) return;
    getCart().forEach(it=>{ const qty=it.qty||1; for(let i=0;i<qty;i++){ addPurchaseSKU(it.sku);} });
    getCart().forEach(it=> incrementSales(it.sku, it.qty||1));
  }
  function bindSuccessPage(){ if(!location.pathname.endsWith("success.html")) return; 
    if(localStorage.getItem("pirana_clear_cart_on_success")==="1"){ clearCart(); setShipping(0); localStorage.removeItem("pirana_clear_cart_on_success"); }
    updateCartCount();
  }

  // boot
  document.addEventListener("DOMContentLoaded",()=>{updateCartCount(); renderCart(); renderSummary(); bindShippingPage(); bindPaymentPage(); renderCatalog(); hydrateProductPageFromSKU(); bindProductPageOptions(); bindProductReviews(); bindSuccessSalesAndPurchases(); bindSuccessPage(); bindAdminPage(); });
})();
