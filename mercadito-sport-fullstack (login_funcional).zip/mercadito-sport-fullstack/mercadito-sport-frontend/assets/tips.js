// assets/tips.js — Tips/Consejos con carrusel + autoplay + inView
(function(){
  const $  = (s, r=document)=> r.querySelector(s);
  const $$ = (s, r=document)=> Array.from(r.querySelectorAll(s));

  // ---- Contenido de ejemplo (ajústalo a tu proyecto) ----
  const TIPS_COMMON = [
    { icon:"📏", tag:"Tallas",  title:"Guía express de calzado",
      text:"Mide el largo del pie: si estás entre dos tallas, elige la mayor. Envíos y cambios gratis.",
      ctas:[{label:"Ver guía", href:"./guia-tallas.html#calzado"}]
    },
    { icon:"⚽", tag:"Fútbol",  title:"¿Césped natural o sintético?",
      text:"Guayos FG para natural, TF para sintético y multitaco si alternas superficies.",
      ctas:[{label:"Ver guayos", href:"./hombre.html?type=calzado&sport=Fútbol"}]
    },
    { icon:"🏃‍♀️", tag:"Running", title:"Zapatillas para 5K–10K",
      text:"Prioriza amortiguación media y drop 6–10mm para entrenos diarios.",
      ctas:[{label:"Ver running", href:"./mujer.html?type=calzado&sport=Running"}]
    },
    { icon:"🧺", tag:"Cuidado", title:"Lava tus prendas técnicas",
      text:"Agua fría, ciclo suave y evita suavizantes para conservar la transpirabilidad.",
      ctas:[{label:"Ver camisetas", href:"./novedades.html?type=camisetas"}]
    },
    { icon:"🔥", tag:"Ofertas", title:"Envío gratis desde $99.900",
      text:"Combina accesorios y alcanza envío gratis. Cambios 30 días.",
      ctas:[{label:"Ir al outlet", href:"./novedades.html?cat=ofertas"}]
    },
    { icon:"🛡️", tag:"Seguro", title:"Pago 100% seguro",
      text:"Protección al comprador y cifrado de extremo a extremo.",
      ctas:[{label:"Cómo pagamos", href:"./checkout.html"}]
    }
  ];

  const TIP_SETS = {
    home:   TIPS_COMMON,
    hombre: TIPS_COMMON,
    mujer:  TIPS_COMMON,
    junior: TIPS_COMMON,
    // agrega más sets si quieres específicos por página
  };

  function cardHTML(t){
    const acts = (t.ctas||[]).map(c=> `<a class="tip-cta" href="${c.href}">${c.label} →</a>`).join("");
    return `
      <article class="tip-card" data-inview="0">
        <div class="tip-body">
          <div class="row" style="gap:10px; align-items:center">
            <div class="tip-ico" aria-hidden="true">${t.icon||"💡"}</div>
            <span class="tip-tag">${t.tag||"Tip"}</span>
          </div>
          <div class="tip-ttl">${t.title||""}</div>
          <div class="tip-txt">${t.text||""}</div>
          <div class="tip-act">${acts}</div>
        </div>
      </article>
    `;
  }

  // Construye un carrusel de tips dentro de el (selector o elemento)
  function initTips(el, tips, {title="Consejos rápidos", autoplayMs=3500} = {}){
    if(typeof el === "string") el = $(el);
    if(!el) return;
    if(!Array.isArray(tips) || !tips.length) tips = TIPS_COMMON;

    el.classList.add("tips");
    el.innerHTML = `
      <div class="tips-head">
        <div class="tips-title">${title}</div>
        <div class="tips-arrows" aria-hidden="true">
          <button class="btn outline icon arrow prev" title="Anterior">‹</button>
          <button class="btn outline icon arrow next" title="Siguiente">›</button>
        </div>
      </div>
      <div class="tips-track" tabindex="0" role="region" aria-label="${title}">
        ${tips.map(cardHTML).join("")}
      </div>
    `;

    const track = el.querySelector(".tips-track");
    const prev  = el.querySelector(".prev");
    const next  = el.querySelector(".next");

    // Navegación
    const step = ()=> Math.max(track.clientWidth * 0.85, 280);
    prev.addEventListener("click", ()=> track.scrollBy({left:-step(), behavior:"smooth"}));
    next.addEventListener("click", ()=> track.scrollBy({left: step(), behavior:"smooth"}));

    // Autoplay (respeta prefers-reduced-motion)
    let timer = null;
    const prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    function start(){
      if(prefersReduced) return;
      stop();
      timer = setInterval(()=> {
        if(!isInViewport(el)) return; // pausa si no está visible
        track.scrollBy({left: step(), behavior:"smooth"});
        // loop suave al final
        if(track.scrollLeft + track.clientWidth >= track.scrollWidth - 2){
          track.scrollTo({left:0, behavior:"smooth"});
        }
      }, autoplayMs);
    }
    function stop(){ if(timer) { clearInterval(timer); timer = null; } }

    el.addEventListener("mouseenter", stop);
    el.addEventListener("mouseleave", start);
    document.addEventListener("visibilitychange", ()=> document.hidden ? stop() : start());
    start();

    // In-view animation para cada card
    const io = new IntersectionObserver(entries=>{
      entries.forEach(en=>{
        const card = en.target;
        card.dataset.inview = en.isIntersecting ? "1" : "0";
      });
    }, { root: track, threshold: 0.4 });
    track.querySelectorAll(".tip-card").forEach(c=> io.observe(c));
  }

  function isInViewport(el){
    const r = el.getBoundingClientRect();
    return r.bottom > 0 && r.right > 0 && r.top < (window.innerHeight||document.documentElement.clientHeight) && r.left < (window.innerWidth||document.documentElement.clientWidth);
  }

  // Auto-inicialización por data-attribute
  document.addEventListener("DOMContentLoaded", ()=>{
    $$(".tips[data-tips]").forEach(el=>{
      const key = el.dataset.tips.trim().toLowerCase();
      initTips(el, TIP_SETS[key] || TIPS_COMMON, { title: el.dataset.title || "Consejos rápidos" });
    });
  });

  // Export opcional
  window.initTips = initTips;
  window.TIPS_COMMON = TIPS_COMMON;
})();
