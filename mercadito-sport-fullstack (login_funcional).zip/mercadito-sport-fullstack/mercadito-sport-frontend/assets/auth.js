// assets/auth.js — Manejo de login/registro en login.html (FRONTEND)
(function () {
  const $ = (s, r = document) => r.querySelector(s);

  function setSession(token, user) {
    // Si tienes un helper Auth, úsalo; si no, guarda en localStorage
    if (window.Auth?.setSession) {
      Auth.setSession({ token, user, role: user?.role });
    } else {
      localStorage.setItem('session', JSON.stringify({ token, user, role: user?.role }));
    }
  }

  function getSession() {
    return (window.Auth?.getSession && window.Auth.getSession())
      || JSON.parse(localStorage.getItem('session') || 'null');
  }

  function redirectByRole(user) {
    location.href = (user?.role === 'admin') ? './admin.html' : './account.html';
  }

  document.addEventListener('DOMContentLoaded', () => {
    // Si ya hay sesión, redirige
    const s = getSession();
    if (s?.token) redirectByRole(s.user || s);

    // ====== LOGIN ======
    const lf = $('#loginForm');
    if (lf) {
      lf.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = $('#loginEmail')?.value?.trim().toLowerCase();
        const password = $('#loginPass')?.value || '';
        const msg = $('#loginMsg');
        const btn = lf.querySelector('button[type="submit"]');

        msg.textContent = 'Ingresando...';
        btn.disabled = true;
        try {
          const { ok, token, user, error } = await Api.login(email, password);
          if (!ok) throw new Error(error || 'No se pudo iniciar sesión');
          setSession(token, user);
          msg.textContent = '¡Listo!';
          redirectByRole(user);
        } catch (err) {
          msg.textContent = err.message || 'No se pudo iniciar sesión';
        } finally {
          btn.disabled = false;
        }
      });
    }

    // ====== REGISTRO ======
    const rf = $('#registerForm');
    if (rf) {
      rf.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = $('#registerEmail')?.value?.trim().toLowerCase();
        const name = $('#registerName')?.value?.trim();
        const password = $('#registerPass')?.value || '';
        const msg = $('#registerMsg');
        const btn = rf.querySelector('button[type="submit"]');

        if (!name) { msg.textContent = 'El nombre es obligatorio'; return; }
        if (!password || password.length < 8) { msg.textContent = 'La contraseña debe tener al menos 8 caracteres'; return; }

        msg.textContent = 'Creando cuenta...';
        btn.disabled = true;
        try {
          const { ok, token, user, error } = await Api.register(email, name, password);
          if (!ok) throw new Error(error || 'No se pudo crear la cuenta');
          setSession(token, user);
          msg.textContent = 'Cuenta creada';
          location.href = './account.html';
        } catch (err) {
          msg.textContent = err.message || 'No se pudo crear la cuenta';
        } finally {
          btn.disabled = false;
        }
      });
    }
  });
})();
