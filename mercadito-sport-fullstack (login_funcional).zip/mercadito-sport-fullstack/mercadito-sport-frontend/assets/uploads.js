(function (w) {
  async function image(file) {
    const fd = new FormData();
    fd.append('image', file);
    const token = w.Auth?.getSession()?.token || '';
    const res = await fetch(w.Api.base + '/upload/image', {
      method: 'POST',
      headers: token ? { 'Authorization': 'Bearer ' + token } : {},
      body: fd
    });
    const data = await res.json();
    if (!res.ok || !data.ok) throw new Error(data?.error || 'No se pudo subir imagen');
    return data.url; // /uploads/...
  }
  w.Upload = { image };
})(window);
