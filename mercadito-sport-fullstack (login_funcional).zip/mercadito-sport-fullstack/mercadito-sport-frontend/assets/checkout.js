// assets/checkout.js — pago + factura (no vacía carrito; asocia usuario si hay sesión)
(function () {
  const $  = (s, r=document)=> r.querySelector(s);
  const S  = window.MSStore;

  if(!S){ console.warn("MSStore no encontrado."); return; }

  const itemsBox = $("#orderItems");
  const subEl = $("#sub"), shipEl = $("#ship"), taxEl = $("#tax"), totalEl = $("#total");

  function lineHTML(it){
    return `
      <div class="row" style="gap:8px; align-items:center">
        <div class="img" style="width:56px;height:56px;overflow:hidden;border-radius:10px">
          <img src="${it.image}" alt="${it.name}" style="width:100%;height:100%;object-fit:cover">
        </div>
        <div style="flex:1">
          <div style="font-weight:600">${it.name}</div>
          <div class="meta">${it.brand} • ${it.sport}</div>
          <div class="meta">x${it.qty} • ${S.fmt(it.unitPrice)}</div>
        </div>
        <div><strong>${S.fmt(it.lineTotal)}</strong></div>
      </div>
    `;
  }
  function renderSummary(){
    const items = S.cartItems();
    itemsBox.innerHTML = items.map(lineHTML).join("") || `<div class="meta">No hay artículos. <a href="./carrito.html">Volver al carrito</a></div>`;
    const t = S.totals();
    subEl.textContent   = S.fmt(t.sub);
    shipEl.textContent  = S.fmt(t.ship);
    taxEl.textContent   = S.fmt(t.tax);
    totalEl.textContent = S.fmt(t.total);
  }

  // Validaciones básicas
  const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const expRe   = /^(0[1-9]|1[0-2])\/\d{2}$/;
  const cardRe  = /^[0-9 ]{12,19}$/;
  const cvvRe   = /^\d{3,4}$/;

  $("#confirmar")?.addEventListener("click", ()=>{
    const items = S.cartItems();
    if(items.length === 0){ alert("Tu carrito está vacío."); location.href="./carrito.html"; return; }

    const data = {
      firstName: $("#firstName").value.trim(), lastName : $("#lastName").value.trim(),
      email    : $("#email").value.trim(),    phone    : $("#phone").value.trim(),
      address  : $("#address").value.trim(),  city     : $("#city").value.trim(),
      state    : $("#state").value.trim(),    zip      : $("#zip").value.trim(),
      doc      : $("#doc").value.trim(),
      cardNumber: $("#cardNumber").value.trim(), cardName: $("#cardName").value.trim(),
      cardExp: $("#cardExp").value.trim(),       cardCvv: $("#cardCvv").value.trim(),
      terms: $("#terms").checked
    };

    if(!data.firstName || !data.lastName || !data.email || !data.phone || !data.address || !data.city || !data.state || !data.zip){ alert("Completa todos los campos de envío."); return; }
    if(!emailRe.test(data.email)){ alert("Email inválido."); return; }
    if(!cardRe.test(data.cardNumber.replace(/\s+/g,''))){ alert("Número de tarjeta inválido (demo)."); return; }
    if(!expRe.test(data.cardExp)){ alert("Expiración inválida (usa MM/AA)."); return; }
    if(!cvvRe.test(data.cardCvv)){ alert("CVV inválido."); return; }
    if(!data.terms){ alert("Debes aceptar los términos y condiciones."); return; }

    const t = S.totals(); const orderId = S.genOrderId(); const now = new Date();
    const session = (window.Auth && Auth.getSession && Auth.getSession()) || null;

    
    // Llamar API
    try{
      const apiItems = items.map(it => ({ product_id: it.id, qty: it.qty }));
      const payload = {
        items: apiItems,
        first_name: data.firstName, last_name: data.lastName,
        email: data.email, phone: data.phone, address: data.address,
        city: data.city, state: data.state, zip: data.zip, doc: data.doc
      };
      const res = await window.Api.createOrder(payload);
      // Mostrar link a factura
      const invUrl = window.Api.base + `/orders/${res.order_id}/invoice`;
      const box = document.getElementById("invoiceBox");
      const cont = document.getElementById("invoiceContent");
      if (box && cont) {
        cont.innerHTML = `<div class="row" style="justify-content:space-between;align-items:flex-start">
          <div><div class="title">Factura</div>
          <div class="meta">Pedido: <strong>${res.order_code}</strong></div></div>
          <div class="meta"><a class="btn" href="${invUrl}" target="_blank" rel="noopener">Descargar factura (PDF)</a></div>
        </div>`;
        box.style.display = "block";
      }
      alert("¡Pago confirmado! Tu pedido quedó registrado.");
      window.scrollTo({ top: 0, behavior: "smooth" });
      // S.clearCart(); // opcional
      renderSummary();
    }catch(err){
      alert("No se pudo crear la orden: " + (err.message||err));
    }

  });

  renderSummary();
})();
