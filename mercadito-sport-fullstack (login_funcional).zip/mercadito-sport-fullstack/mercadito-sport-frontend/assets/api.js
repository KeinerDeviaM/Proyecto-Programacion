// assets/api.js — Cliente REST para la API
(function(w){
  const API_BASE = w.API_BASE || "http://localhost:4000";
  function authHeader(){
    try{
      const s = w.Auth && w.Auth.getSession && w.Auth.getSession();
      if(s?.token) return { 'Authorization': 'Bearer ' + s.token };
    }catch{} return {};
  }
  async function req(path, opts={}){
    const url = API_BASE + path;
    const headers = Object.assign({'Content-Type':'application/json'}, authHeader(), opts.headers||{});
    const res = await fetch(url, Object.assign({}, opts, { headers }));
    let data = null;
    try{ data = await res.json(); }catch{}
    if(!res.ok) throw new Error((data && (data.error || data.message)) || ('HTTP '+res.status));
    return data;
  }
  const Api = {
    base: API_BASE,
    // auth
    async register(email,name,password){ return req('/auth/register', {method:'POST', body: JSON.stringify({email,name,password})}); },
    async login(email,password){ return req('/auth/login', {method:'POST', body: JSON.stringify({email,password})}); },
    me(){ return req('/auth/me'); },
    // products
    listProducts(params={}){
      const q = new URLSearchParams(params);
      return req('/products' + (q.toString()? ('?'+q.toString()):''));
    },
    getProduct(id){ return req('/products/'+id); },
    // submissions
    listSubmissions(params={}){
      const q = new URLSearchParams(params);
      return req('/submissions' + (q.toString()? ('?'+q.toString()):''));
    },
    deleteSubmission(id){ return req('/submissions/'+id, { method:'DELETE' }); },

    createSubmission(payload){ return req('/submissions', {method:'POST', body: JSON.stringify(payload)}); },
    approveSubmission(id){ return req('/submissions/'+id+'/approve', {method:'POST'}); },
    rejectSubmission(id){ return req('/submissions/'+id+'/reject', {method:'POST'}); },
    // reviews
    createReview(payload){ return req('/reviews', {method:'POST', body: JSON.stringify(payload)}); },
    deleteReview(id){ return req('/reviews/'+id, {method:'DELETE'}); },
    // orders
    createOrder(payload){ return req('/orders', {method:'POST', body: JSON.stringify(payload)}); },
    listOrders(params={}){ const q = new URLSearchParams(params); return req('/orders' + (q.toString()? ('?'+q.toString()):'')); },
    getOrder(id){ return req('/orders/'+id); }
  };
  w.Api = Api;
  
})(window);
