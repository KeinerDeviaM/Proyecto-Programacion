// assets/store.js — Carrito (local) + puente hacia API para catálogo/submissions/órdenes
(function(w){
  const LS = { CART: "ms_cart" };
  const read = (k,def)=> { try{ return JSON.parse(localStorage.getItem(k) || JSON.stringify(def)); }catch{ return def; } };
  const write = (k,val)=> localStorage.setItem(k, JSON.stringify(val));
  const fmt = (n)=> new Intl.NumberFormat("es-CO",{style:"currency",currency:"COP"}).format(n||0);

  // ==== Carrito local ====
  function getCart(){ return read(LS.CART, {}); }
  function saveCart(c){ write(LS.CART, c || {}); w.dispatchEvent(new CustomEvent('ms:cart:updated')); }
  function addToCart(id, qty=1){ const c = getCart(); c[id] = (c[id]||0) + qty; saveCart(c); }
  function removeFromCart(id){ const c = getCart(); delete c[id]; saveCart(c); }
  function setQty(id, qty){ const c = getCart(); if(qty<=0) delete c[id]; else c[id]=qty; saveCart(c); }
  function clearCart(){ saveCart({}); }
  function totals(productsIndex){
    const c = getCart(); let sub=0;
    for (const [id, qty] of Object.entries(c)){
      const p = productsIndex?.get(Number(id)) || null;
      if (!p) continue;
      const unit = Math.round(p.price_cop * (1 - (p.discount_pct||0)/100));
      sub += unit * qty;
    }
    const ship = 9900, tax = Math.round(sub*0.19), total = sub + ship + tax;
    return { sub, ship, tax, total };
  }
  async function cartItems(){
    // Map cart ids to product info from API
    const c = getCart();
    const ids = Object.keys(c).map(x=>parseInt(x,10)).filter(Boolean);
    const out = [];
    // fetch individually (simple, could be optimized)
    for(const id of ids){
      try{ const data = await w.Api.getProduct(id); const p = data.product;
        const unit = Math.round(p.price_cop * (1 - (p.discount_pct||0)/100));
        out.push({ id: p.id, name: p.name, brand: p.brand, sport: p.sport, image: p.image_url, qty: c[id], unitPrice: unit, lineTotal: unit * c[id] });
      }catch(e){ /* ignore */ }
    }
    return out;
  }

  // ==== API bridges ====
  async function getProducts(params){ const res = await w.Api.listProducts(params||{}); return res.items || []; }
  async function getProduct(id){ const res = await w.Api.getProduct(id); return res.product; }
  async function submitProduct(payload){ const res = await w.Api.createSubmission(payload); return res.submission; }
  async function listMySubmissions(){ const res = await w.Api.listSubmissions(); return res.items||[]; }
  async function approveSubmission(id){ const res = await w.Api.approveSubmission(id); return res.product; }
  async function rejectSubmission(id){ const res = await w.Api.rejectSubmission(id); return true; }
  function genOrderId(){ return 'MS' + Math.floor(Date.now()/1000).toString(36).toUpperCase().padStart(8,'0'); }
  async function deleteSubmission(id){ await w.Api.deleteSubmission(id); return true; }

  w.MSStore = { fmt, getProducts, getProduct, submitProduct, listMySubmissions, approveSubmission, rejectSubmission,
                addToCart, removeFromCart, setQty, clearCart, cartItems, totals, genOrderId };
})(window);
