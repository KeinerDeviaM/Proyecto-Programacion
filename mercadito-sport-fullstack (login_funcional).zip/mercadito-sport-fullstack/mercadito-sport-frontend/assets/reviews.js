// assets/reviews.js — Reseñas con backend
(function (w, d) {
  "use strict";
  async function list(productId){
    const res = await w.Api.getProduct(productId);
    return res.product?.reviews || [];
  }
  function stats(productId){
    // Nota: se puede usar vw_products_with_rating por API de productos (ya viene el promedio)
    // Aquí calculamos con el array si se quiere.
    return list(productId).then(arr => {
      if(!arr.length) return { avg:0, count:0 };
      const sum = arr.reduce((a,b)=> a + (b.rating||0), 0);
      return { avg: Math.round((sum/arr.length)*10)/10, count: arr.length };
    });
  }
  async function create(productId, rating, title, body){
    const res = await w.Api.createReview({ product_id: productId, rating, title, body });
    // notificar
    w.dispatchEvent(new CustomEvent('ms:reviews:updated', { detail:{ productId } }));
    return res.review;
  }
  async function remove(id, productId){
    await w.Api.deleteReview(id);
    w.dispatchEvent(new CustomEvent('ms:reviews:updated', { detail:{ productId } }));
    return true;
  }
  w.Reviews = { list, stats, create, remove };
})(window, document);
