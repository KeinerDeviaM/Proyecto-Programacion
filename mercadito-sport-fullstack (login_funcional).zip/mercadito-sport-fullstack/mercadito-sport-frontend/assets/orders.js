// assets/orders.js — Mis pedidos (desde backend)
(function(){
  const $ = (s, r=document)=> r.querySelector(s);
  const list = $("#ordersList");
  if(!list) return;
  async function load(){
    try{
      const res = await window.Api.listOrders();
      const items = res.items || [];
      list.innerHTML = items.map(o => `
        <div class="order-card">
          <div class="row" style="justify-content:space-between">
            <div><strong>${o.order_code}</strong> — ${new Date(o.created_at).toLocaleString()}</div>
            <div class="meta">${o.status}</div>
          </div>
          <div class="row" style="justify-content:space-between">
            <div class="meta">Subtotal: $${o.sub_total} • Envío: $${o.ship_total} • IVA: $${o.tax_total}</div>
            <a class="btn outline small" href="${window.Api.base}/orders/${o.id}/invoice" target="_blank" rel="noopener">Factura PDF</a>
          </div>
        </div>
      `).join("");
    }catch(e){
      list.innerHTML = `<div class="meta">No se pudieron cargar tus pedidos: ${e.message||e}</div>`;
    }
  }
  document.addEventListener("DOMContentLoaded", load);
})();
