(function () {
  const $ = (s, r = document) => r.querySelector(s);
  const box = $('#adminStats');
  if (!box) return;

  function pesos(n){ return new Intl.NumberFormat('es-CO',{style:'currency',currency:'COP'}).format(n||0); }

  async function load() {
    try {
      const token = window.Auth?.getSession()?.token || '';
      const res = await fetch(window.Api.base + '/admin/stats', {
        headers: token ? { 'Authorization': 'Bearer ' + token } : {}
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data?.error || 'Error');

      const c = data.counters || {users:0,products:0,orders:0,sales:0};
      const brands = data.topBrands || [];
      const prods = data.topProducts || [];
      const days = data.sales7 || [];

      box.innerHTML = `
        <div class="grid" style="grid-template-columns: repeat(auto-fit,minmax(200px,1fr)); gap:12px">
          <div class="card"><div class="title">Usuarios</div><div class="kpi">${c.users}</div></div>
          <div class="card"><div class="title">Productos</div><div class="kpi">${c.products}</div></div>
          <div class="card"><div class="title">Órdenes</div><div class="kpi">${c.orders}</div></div>
          <div class="card"><div class="title">Ventas</div><div class="kpi">${pesos(c.sales)}</div></div>
        </div>

        <div class="row" style="gap:20px; margin-top:16px; align-items:flex-start">
          <div class="card" style="flex:1">
            <div class="title">Ventas últimos 7 días</div>
            <div class="list">
              ${days.map(d=>`<div class="row" style="justify-content:space-between"><span>${d.day}</span><strong>${pesos(d.total)}</strong></div>`).join('')}
            </div>
          </div>
          <div class="card" style="flex:1">
            <div class="title">Top marcas</div>
            <div class="list">
              ${brands.map(b=>`<div class="row" style="justify-content:space-between"><span>${b.brand}</span><strong>${pesos(b.total)}</strong></div>`).join('')}
            </div>
          </div>
          <div class="card" style="flex:1">
            <div class="title">Top productos</div>
            <div class="list">
              ${prods.map(p=>`<div class="row" style="justify-content:space-between"><span>${p.name}</span><strong>${pesos(p.total)} (${p.qty})</strong></div>`).join('')}
            </div>
          </div>
        </div>
      `;
    } catch (e) {
      box.innerHTML = `<div class="meta">No se pudo cargar el dashboard: ${e.message}</div>`;
    }
  }
  document.addEventListener('DOMContentLoaded', load);
})();
