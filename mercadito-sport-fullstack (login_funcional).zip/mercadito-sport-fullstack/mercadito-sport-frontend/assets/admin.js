// assets/admin.js — Panel simple de admin con Submissions del backend
(function(){
  const $ = (s, r=document)=> r.querySelector(s);
  const $$= (s, r=document)=> Array.from(r.querySelectorAll(s));
  const listEl = $("#adminSubmissions");
  if (!listEl) return;

  async function load(){
    try{
      const res = await window.Api.listSubmissions();
      const items = res.items || [];
      listEl.innerHTML = items.map(s => `
        <div class="card" style="padding:10px;margin:8px 0">
          <div class="row" style="justify-content:space-between;align-items:center">
            <div>
              <div><strong>${s.name}</strong> — ${s.brand} • ${s.department} • ${s.sport}</div>
              <div class="meta">Estado: ${s.status} • $${s.price_cop} • Stock: ${s.stock}</div>
            </div>
            <div class="row" style="gap:6px">
              ${s.status==='pendiente' ? `<button class="btn small btn-approve" data-id="${s.id}">Aprobar</button>
              <button class="btn outline small btn-reject" data-id="${s.id}">Rechazar</button>` : `<span class="badge">${s.status}</span>`}
            </div>
          </div>
        </div>
      `).join("");
      $$(".btn-approve", listEl).forEach(b=> b.addEventListener("click", async ()=>{
        try{ await window.Api.approveSubmission(b.dataset.id); await load(); }catch(e){ alert(e.message||e); }
      }));
      $$(".btn-reject", listEl).forEach(b=> b.addEventListener("click", async ()=>{
        try{ await window.Api.rejectSubmission(b.dataset.id); await load(); }catch(e){ alert(e.message||e); }
      }));
    }catch(e){
      listEl.innerHTML = `<div class="meta">Error cargando envíos: ${e.message||e}</div>`;
    }
  }
  document.addEventListener("DOMContentLoaded", load);
})();
