-- Mercadito Sport — Datos de ejemplo (puedes modificar/retirar)
USE mercadito_sport;

-- Usuarios (admin + cliente demo)
INSERT INTO users (email, name, role, pass_hash) VALUES
  ('adminkeiner@gmail.com', 'Admin Keiner', 'admin', '2lfEZPJvvxt7Ik3V5buraiVNovNZNjSxiPBiHF5ONds='),
  ('cliente@demo.com',  'Cliente Demo', 'user',  '1iK32cA2QQgKzBbbWUTYbAzmcdbkdX+5BeEJHDWa+ho=');

-- Un producto aprobado de ejemplo
INSERT INTO products (seller_id, name, price_cop, discount_pct, stock, department, sport, type, brand, image_url, description)
VALUES
  (NULL, 'Guayos Fútbol Pro FG', 259900, 0, 24, 'Hombre', 'Fútbol', 'calzado', 'StrideX', 
   'https://images.unsplash.com/photo-1601462252103-5c98e2acb28c?q=80&w=1600&auto=format&fit=crop',
   'Taco firme FG para césped natural, upper sintético texturizado y placa ligera de tracción.');

SET @p1 = LAST_INSERT_ID();

INSERT INTO product_colors (product_id, name, hex) VALUES
  (@p1, 'Negro', '#111827'),
  (@p1, 'Rojo',  '#b91c1c');

INSERT INTO product_tags (product_id, tag) VALUES
  (@p1, 'nuevo'),
  (@p1, 'oferta');

-- Reseña de ejemplo
INSERT INTO reviews (product_id, user_id, rating, title, body)
SELECT @p1, id, 5, 'Excelente agarre', 'Muy cómodos y con buen agarre en cancha húmeda.'
FROM users WHERE email = 'cliente@demo.com' LIMIT 1;

-- Pedido de ejemplo
INSERT INTO orders (
  order_code, user_id, status, sub_total, ship_total, tax_total, grand_total,
  first_name, last_name, email, phone, address, city, state, zip, doc
)
SELECT
  CONCAT('MS', LPAD(CONV(FLOOR(UNIX_TIMESTAMP()), 10, 36), 8, '0')),
  id, 'pagado', 259900, 9900, ROUND(259900 * 0.19), 259900 + 9900 + ROUND(259900 * 0.19),
  'Juan', 'Pérez', 'cliente@demo.com', '3001234567', 'Calle Falsa 123', 'Bogotá', 'Cundinamarca', '110111', 'CC 12345678'
FROM users WHERE email = 'cliente@demo.com' LIMIT 1;

SET @o1 = LAST_INSERT_ID();

INSERT INTO order_items (order_id, product_id, qty, unit_price, line_total, name_snap, brand_snap, image_snap)
VALUES
  (@o1, @p1, 1, 259900, 259900, 'Guayos Fútbol Pro FG', 'StrideX',
   'https://images.unsplash.com/photo-1601462252103-5c98e2acb28c?q=80&w=1600&auto=format&fit=crop');
