# Mercadito Sport — Node/Express API (estilo *mascotas-api*)

Backend en **Node.js + Express + mysql2 + pdfkit + JWT**, inspirado en la estructura de *mascotas-api* que nos compartiste.
Apunta a la base de datos `mercadito_sport` que ya importaste con los `.sql` anteriores.

## Requisitos
- Node 18+
- XAMPP/MySQL corriendo (DB: `mercadito_sport` en localhost)

## Instalación
```bash
cd mercadito-sport-node-api
cp .env.example .env   # (opcional) o usa variables de entorno del sistema
npm install
npm start
```
Por defecto levanta en `http://localhost:4000`.

## Configuración
Edita `config.js` o usa variables de entorno `.env`:
- `APP_SECRET` (pon una cadena larga aleatoria)
- `DB_HOST, DB_PORT, DB_USER, DB_PASS, DB_NAME` (ajústalos a tu XAMPP)

## Endpoints
### Auth
- `POST /auth/register` `{ email, name, password }`
- `POST /auth/login` `{ email, password }` → `{ token, user }`
- `GET /auth/me` *(Bearer token)*

> Hash compatible con tu frontend: `base64( SHA-256( lower(email) + '::' + password ) )`

### Products
- `GET /products?q=&department=&sport=&type=&brand=&limit=&offset=`
- `GET /products/:id`

### Submissions (vendedor/admin)
- `GET /submissions` *(user: las suyas / admin: todas, `?status=`)*
- `POST /submissions` `{ name, price_cop, discount_pct, stock, department, sport, type, brand, image_url, description, colors:[{name,hex}], tags:[string] }`
- `POST /submissions/:id/approve` *(admin)*
- `POST /submissions/:id/reject`  *(admin)*

### Reviews
- `POST /reviews` `{ product_id, rating(1..5), title?, body? }`
- `DELETE /reviews/:id` *(dueño o admin)*

### Orders + Factura PDF (estilo *mascotas-api*)
- `POST /orders`
  ```json
  {
    "items":[ {"product_id":1,"qty":1} ],
    "first_name":"Juan","last_name":"Pérez","email":"cliente@demo.com",
    "phone":"3001234567","address":"Calle 123","city":"Bogotá","state":"Cundinamarca","zip":"110111","doc":"CC 12345678"
  }
  ```
  Respuesta: `{ order_code, order_id, factura:"/orders/{id}/invoice", totals:{...} }`

- `GET /orders/:id/invoice` → **PDF** generado con `pdfkit` y guardado en `./facturas` (como en *mascotas-api*).

## Notas
- CORS habilitado en desarrollo.
- Totales de órdenes: IVA 19% + envío por defecto 9.900 COP (puedes cambiarlo en la request).
- Uso de **transacciones** para crear órdenes y disminuir stock.
