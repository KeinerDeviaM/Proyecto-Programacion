import express from 'express';
import { q, pool } from '../db.js';
import { needAuth } from '../middlewares/auth.js';
import { generarFacturaPDF, facturaPath } from '../factura.js';
import fs from 'fs';

const router = express.Router();

function orderCode() {
  const base36 = Math.floor(Date.now()/1000).toString(36).toUpperCase();
  return 'MS' + base36.padStart(8,'0');
}

router.post('/', async (req,res)=> {
  try {
    const auth = req.headers['authorization'];
    let user = null;
    if (auth) {
      try { const jwt = (await import('jsonwebtoken')).default; const { APP } = await import('../config.js');
        user = jwt.verify(auth.replace(/Bearer\s+/i,''), APP.SECRET);
      } catch {}
    }
    const inb = req.body || {};
    const items = Array.isArray(inb.items) ? inb.items : [];
    if (!items.length) return res.status(422).json({ ok:false, error:'Carrito vacío' });
    const reqFields = ['first_name','last_name','email','phone','address','city','state','zip'];
    for (const k of reqFields) if (!inb[k]) return res.status(422).json({ ok:false, error:`Campo requerido: ${k}` });

    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();
      let sub_total = 0;
      const resolved = [];
      for (const it of items) {
        const pid = parseInt(it.product_id,10)||0;
        const qty = Math.max(1, parseInt(it.qty,10)||1);
        const [rows] = await conn.execute("SELECT id,name,brand,price_cop,discount_pct,stock,image_url FROM products WHERE id=? FOR UPDATE", [pid]);
        if (!rows.length) throw new Error(`Producto ${pid} no existe`);
        const p = rows[0];
        if (p.stock < qty) throw new Error(`Stock insuficiente para ${p.name}`);
        const unit = Math.round(p.price_cop * (1 - (p.discount_pct||0)/100));
        const line = unit * qty;
        sub_total += line;
        resolved.push({ pid, qty, unit, line, name: p.name, brand: p.brand, img: p.image_url });
      }
      const ship_total = parseInt(inb.ship_total||9900,10);
      const tax_total  = Math.round(sub_total * 0.19);
      const grand_total = sub_total + ship_total + tax_total;

      const code = orderCode();
      const [orRes] = await conn.execute(
        "INSERT INTO orders (order_code,user_id,status,sub_total,ship_total,tax_total,grand_total,first_name,last_name,email,phone,address,city,state,zip,doc) VALUES (?,?, 'pagado',?,?,?,?,?,?,?,?,?,?,?,?)",
        [code, user?.sub || null, sub_total, ship_total, tax_total, grand_total, inb.first_name, inb.last_name, inb.email, inb.phone, inb.address, inb.city, inb.state, inb.zip, inb.doc || null]
      );
      const orderId = orRes.insertId;

      for (const ri of resolved) {
        await conn.execute(
          "INSERT INTO order_items (order_id,product_id,qty,unit_price,line_total,name_snap,brand_snap,image_snap) VALUES (?,?,?,?,?,?,?,?)",
          [orderId, ri.pid, ri.qty, ri.unit, ri.line, ri.name, ri.brand, ri.img]
        );
        await conn.execute("UPDATE products SET stock = stock - ? WHERE id=?", [ri.qty, ri.pid]);
      }

      await conn.commit();

      // Fetch order & items to generate invoice PDF (like mascotas-api style)
      const [orderRow] = await q("SELECT * FROM orders WHERE id=?", [orderId]);
      const itemsRows = await q("SELECT * FROM order_items WHERE order_id=?", [orderId]);
      await generarFacturaPDF(orderRow, itemsRows);

      res.status(201).json({ ok:true, order_code: code, order_id: orderId, factura: `/orders/${orderId}/invoice`, totals: { sub_total, ship_total, tax_total, grand_total } });
    } catch (e) {
      try { await conn.rollback(); } catch {}
      res.status(400).json({ ok:false, error: 'No se pudo crear la orden: ' + e.message });
    } finally {
      conn.release();
    }
  } catch (e) {
    res.status(500).json({ ok:false, error: e.message });
  }
});

router.get('/:id/invoice', async (req,res)=> {
  try {
    const id = parseInt(req.params.id,10)||0;
    if (!id) return res.status(400).json({ ok:false, error:'ID inválido'});
    const [order] = await q("SELECT * FROM orders WHERE id=?", [id]);
    if (!order) return res.status(404).json({ ok:false, error:'Orden no encontrada'});
    const file = facturaPath(id);
    if (!fs.existsSync(file)) {
      const items = await q("SELECT * FROM order_items WHERE order_id=?", [id]);
      await generarFacturaPDF(order, items);
    }
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="factura_${id}.pdf"`);
    fs.createReadStream(file).pipe(res);
  } catch (e) {
    res.status(500).json({ ok:false, error: e.message });
  }
});

export default router;

// Extra: listar órdenes
router.get('/', needAuth(), async (req,res)=>{
  try{
    const isAdmin = req.user?.role === 'admin';
    if(isAdmin && req.query.all === '1'){
      const items = await q("SELECT * FROM orders ORDER BY created_at DESC LIMIT 200");
      return res.json({ ok:true, items });
    }
    const items = await q("SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC", [req.user.sub]);
    res.json({ ok:true, items });
  }catch(e){
    res.status(500).json({ ok:false, error: e.message });
  }
});

router.get('/:id', needAuth(), async (req,res)=>{
  try{
    const id = parseInt(req.params.id, 10)||0;
    const [order] = await q("SELECT * FROM orders WHERE id=?", [id]);
    if(!order) return res.status(404).json({ ok:false, error:'Orden no encontrada' });
    if(order.user_id !== req.user.sub && (req.user.role!=='admin')) return res.status(403).json({ ok:false, error:'No autorizado' });
    const items = await q("SELECT * FROM order_items WHERE order_id=?", [id]);
    res.json({ ok:true, order, items });
  }catch(e){
    res.status(500).json({ ok:false, error: e.message });
  }
});
