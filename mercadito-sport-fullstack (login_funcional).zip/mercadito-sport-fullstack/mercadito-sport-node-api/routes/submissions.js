import express from 'express';
import { q } from '../db.js';
import { needAuth } from '../middlewares/auth.js';

const router = express.Router();

router.get('/', needAuth(), async (req, res) => {
  try {
    const isAdmin = (req.user.role === 'admin');
    let where = "1=1";
    const params = [];
    if (!isAdmin) {
      where = "owner_id = ?"; params.push(req.user.sub);
    } else if (req.query.status) {
      where = "status = ?"; params.push(req.query.status);
    }
    const rows = await q(`SELECT * FROM product_submissions WHERE ${where} ORDER BY created_at DESC`, params);
    res.json({ ok:true, items: rows });
  } catch (e) {
    res.status(500).json({ ok:false, error: e.message });
  }
});

router.post('/', needAuth(), async (req, res) => {
  try {
    const f = ['name','price_cop','discount_pct','stock','department','sport','type','brand','image_url','description'];
    const data = {};
    for (const k of f) data[k] = req.body?.[k] ?? null;
    data.owner_id = req.user.sub;
    data.status = 'pendiente';
    await q(`INSERT INTO product_submissions (owner_id,status,name,price_cop,discount_pct,stock,department,sport,type,brand,image_url,description)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
             [data.owner_id,data.status,data.name,data.price_cop,data.discount_pct||0,data.stock||0,data.department,data.sport,data.type,data.brand,data.image_url,data.description]);
    const [sub] = await q("SELECT * FROM product_submissions WHERE id = LAST_INSERT_ID()");

    const colors = Array.isArray(req.body?.colors) ? req.body.colors : [];
    for (const c of colors) {
      await q("INSERT INTO submission_colors (submission_id,name,hex) VALUES (?,?,?)",
              [sub.id, c.name || 'Color', c.hex || '#111827']);
    }
    const tags = Array.isArray(req.body?.tags) ? req.body.tags : [];
    for (const t of tags) {
      await q("INSERT INTO submission_tags (submission_id,tag) VALUES (?,?)", [sub.id, t]);
    }
    res.status(201).json({ ok:true, submission: sub });
  } catch (e) {
    res.status(500).json({ ok:false, error: e.message });
  }
});

router.post('/:id/approve', needAuth(['admin']), async (req, res) => {
  const sid = parseInt(req.params.id,10);
  try {
    const subs = await q("SELECT * FROM product_submissions WHERE id=?", [sid]);
    if (!subs.length) return res.status(404).json({ ok:false, error:'Submisión no existe' });
    const s = subs[0];

    // Start transaction
    const conn = await (await import('mysql2/promise')).createConnection({ ...(await (await import('../config.js')).DB) });
  } catch (e) {
    // fallback simpler approach using pool getConnection
  }
  try {
    const mysql = (await import('mysql2/promise')).default;
    const cfg = (await import('../config.js')).DB;
    const conn = await mysql.createConnection(cfg);
    try {
      await conn.beginTransaction();

      const [r1] = await conn.execute(
        "INSERT INTO products (seller_id,name,price_cop,discount_pct,stock,department,sport,type,brand,image_url,description) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        [s.owner_id, s.name, s.price_cop, s.discount_pct, s.stock, s.department, s.sport, s.type, s.brand, s.image_url, s.description]
      );
      const pid = r1.insertId;

      const cols = await q("SELECT name,hex FROM submission_colors WHERE submission_id=?", [sid]);
      for (const c of cols) {
        await conn.execute("INSERT INTO product_colors (product_id,name,hex) VALUES (?,?,?)", [pid, c.name, c.hex]);
      }
      const tags = await q("SELECT tag FROM submission_tags WHERE submission_id=?", [sid]);
      for (const t of tags) {
        await conn.execute("INSERT INTO product_tags (product_id,tag) VALUES (?,?)", [pid, t.tag]);
      }

      await conn.execute("UPDATE product_submissions SET status='aprobado', product_id=? WHERE id=?", [pid, sid]);

      await conn.commit();
      const [prod] = await q("SELECT * FROM products WHERE id=?", [pid]);
      res.json({ ok:true, product: prod });
    } catch (e) {
      await (async ()=>{ try { await conn.rollback(); } catch{} })();
      throw e;
    } finally {
      try { await conn.end(); } catch {}
    }
  } catch (e) {
    res.status(500).json({ ok:false, error: 'No se pudo aprobar: ' + e.message });
  }
});

router.post('/:id/reject', needAuth(['admin']), async (req, res) => {
  try {
    await q("UPDATE product_submissions SET status='rechazado' WHERE id=?", [req.params.id]);
    res.json({ ok:true });
  } catch (e) {
    res.status(500).json({ ok:false, error: e.message });
  }
});
router.delete('/:id', needAuth(), async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10) || 0;
    const [row] = await q("SELECT id, owner_id, status FROM product_submissions WHERE id=?", [id]);
    if (!row) return res.status(404).json({ ok:false, error:'No encontrado' });

    const isOwner = row.owner_id === req.user.sub;
    const isAdmin = req.user.role === 'admin';
    if (!isOwner && !isAdmin) return res.status(403).json({ ok:false, error:'No autorizado' });
    if (row.status === 'aprobado' && !isAdmin) {
      return res.status(409).json({ ok:false, error:'No se puede borrar un envío aprobado' });
    }

    await q("DELETE FROM submission_colors WHERE submission_id=?", [id]);
    await q("DELETE FROM submission_tags  WHERE submission_id=?", [id]);
    await q("DELETE FROM product_submissions WHERE id=?", [id]);
    res.json({ ok:true });
  } catch (e) {
    res.status(500).json({ ok:false, error: e.message });
  }
});


export default router;
