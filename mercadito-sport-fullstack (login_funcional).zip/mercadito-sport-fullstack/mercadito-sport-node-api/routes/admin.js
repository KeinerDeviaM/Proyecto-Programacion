import express from 'express';
import { q } from '../db.js';
import { needAuth } from '../middlewares/auth.js';

const router = express.Router();

router.get('/stats', needAuth(['admin']), async (req, res) => {
  try {
    const [[u],[p],[o],[s]] = await Promise.all([
      q('SELECT COUNT(*) AS users FROM users'),
      q('SELECT COUNT(*) AS products FROM products'),
      q('SELECT COUNT(*) AS orders FROM orders'),
      q("SELECT COALESCE(SUM(grand_total),0) AS sales FROM orders WHERE status='pagado'")
    ]);

    const sales7 = await q(`
      SELECT DATE(created_at) AS day, SUM(grand_total) AS total
        FROM orders
       WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) AND status='pagado'
       GROUP BY DATE(created_at)
       ORDER BY day
    `);

    const topBrands = await q(`
      SELECT p.brand, SUM(oi.line_total) AS total
        FROM order_items oi
        JOIN products p ON p.id = oi.product_id
        JOIN orders o ON o.id = oi.order_id
       WHERE o.status='pagado'
       GROUP BY p.brand
       ORDER BY total DESC
       LIMIT 5
    `);

    const topProducts = await q(`
      SELECT p.id, p.name, SUM(oi.qty) AS qty, SUM(oi.line_total) AS total
        FROM order_items oi
        JOIN products p ON p.id = oi.product_id
        JOIN orders o ON o.id = oi.order_id
       WHERE o.status='pagado'
       GROUP BY p.id, p.name
       ORDER BY total DESC
       LIMIT 5
    `);

    res.json({
      ok: true,
      counters: { users: u.users, products: p.products, orders: o.orders, sales: s.sales },
      sales7,
      topBrands,
      topProducts
    });
  } catch (e) {
    res.status(500).json({ ok:false, error:e.message });
  }
});

export default router;
