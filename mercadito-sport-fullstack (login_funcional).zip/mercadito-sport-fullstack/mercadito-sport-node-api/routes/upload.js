import express from 'express';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';
import { needAuth } from '../middlewares/auth.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(__dirname, '..');
const UP_DIR = path.join(root, 'uploads');
import fs from 'fs';

// crea el directorio si no existe
if (!fs.existsSync(UP_DIR)) {
  fs.mkdirSync(UP_DIR, { recursive: true });
}


const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UP_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const safe = Date.now() + '_' + Math.random().toString(36).slice(2) + ext;
    cb(null, safe);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB
  fileFilter: (req, file, cb) => {
    if (!file.mimetype.startsWith('image/')) return cb(new Error('Solo imágenes'));
    cb(null, true);
  }
});

const router = express.Router();

// Solo usuarios autenticados (vendedor/admin)
router.post('/image', needAuth(), upload.single('image'), (req, res) => {
  const fname = req.file.filename;
  return res.status(201).json({ ok:true, url: `/uploads/${fname}` });
});

export default router;
