import express from 'express';
import { q } from '../db.js';

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const {
      q:term = '',
      department = '',
      sport = '',
      type = '',
      brand = '',
      min_price = '',
      max_price = '',
      sort = 'newest',      // newest | price_asc | price_desc | rating_desc
      page = '1',
      pageSize = '24'
    } = req.query;

    const p = Math.max(1, parseInt(page,10) || 1);
    const ps = Math.max(1, Math.min(100, parseInt(pageSize,10) || 24));
    const off = (p - 1) * ps;

    // Base WHERE
    let where = '1=1';
    const params = [];

    if (term) { where += ' AND (p.name LIKE ? OR p.brand LIKE ? )'; params.push(`%${term}%`,`%${term}%`); }
    if (department) { where += ' AND p.department = ?'; params.push(department); }
    if (sport) { where += ' AND p.sport = ?'; params.push(sport); }
    if (type) { where += ' AND p.type = ?'; params.push(type); }
    if (brand) { where += ' AND p.brand = ?'; params.push(brand); }

    // precio final con descuento
    const priceExpr = 'ROUND(p.price_cop * (1 - (p.discount_pct)/100))';
    if (min_price) { where += ` AND ${priceExpr} >= ?`; params.push(parseInt(min_price,10)||0); }
    if (max_price) { where += ` AND ${priceExpr} <= ?`; params.push(parseInt(max_price,10)||0); }

    // Orden
    let order = 'p.created_at DESC';
    if (sort === 'price_asc') order = `${priceExpr} ASC`;
    else if (sort === 'price_desc') order = `${priceExpr} DESC`;
    else if (sort === 'rating_desc') order = 'v.avg_rating DESC, p.created_at DESC';

    // Conteo total
    const [{ total }] = await q(
      `SELECT COUNT(*) AS total
         FROM products p
         LEFT JOIN vw_products_with_rating v ON v.id = p.id
        WHERE ${where}`, params
    );

    // Items
    const rows = await q(
      `SELECT p.id, p.name, p.price_cop, p.discount_pct, p.department, p.sport, p.type, p.brand,
              COALESCE(v.avg_rating,0) AS avg_rating, COALESCE(v.reviews_count,0) AS reviews_count,
              p.image_url
         FROM products p
         LEFT JOIN vw_products_with_rating v ON v.id = p.id
        WHERE ${where}
        ORDER BY ${order}
        LIMIT ? OFFSET ?`, [...params, ps, off]
    );

    res.json({ ok:true, items: rows, total, page: p, pageSize: ps });
  } catch (e) {
    res.status(500).json({ ok:false, error: e.message });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const [p] = await q(`SELECT p.*, COALESCE(v.avg_rating,0) avg_rating, COALESCE(v.reviews_count,0) reviews_count
                         FROM products p LEFT JOIN vw_products_with_rating v ON v.id = p.id WHERE p.id=?`, [id]);
    if (!p) return res.status(404).json({ ok:false, error:'Producto no encontrado' });
    const colors = await q("SELECT id,name,hex FROM product_colors WHERE product_id=?", [id]);
    const tags   = await q("SELECT tag FROM product_tags WHERE product_id=?", [id]);
    const reviews= await q("SELECT r.id, r.rating, r.title, r.body, r.created_at, u.name as user_name FROM reviews r JOIN users u ON u.id = r.user_id WHERE r.product_id=? ORDER BY r.created_at DESC", [id]);
    p.colors = colors;
    p.tags = tags.map(t=>t.tag);
    p.reviews = reviews;
    res.json({ ok:true, product: p });
  } catch (e) {
    res.status(500).json({ ok:false, error: e.message });
  }
});

export default router;
