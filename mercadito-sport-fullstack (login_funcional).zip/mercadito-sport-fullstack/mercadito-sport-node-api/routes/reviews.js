import express from 'express';
import { q } from '../db.js';
import { needAuth } from '../middlewares/auth.js';

const router = express.Router();

router.post('/', needAuth(), async (req,res) => {
  try {
    const { product_id, rating, title=null, body=null } = req.body || {};
    const pid = parseInt(product_id,10)||0;
    const r = parseInt(rating,10)||0;
    if (pid<=0 || r<1 || r>5) return res.status(422).json({ ok:false, error:'Datos de reseña inválidos' });
    const exists = await q("SELECT id FROM reviews WHERE product_id=? AND user_id=?", [pid, req.user.sub]);
    if (exists.length) return res.status(409).json({ ok:false, error:'Ya has reseñado este producto' });
    await q("INSERT INTO reviews (product_id,user_id,rating,title,body) VALUES (?,?,?,?,?)",[pid, req.user.sub, r, title, body]);
    const [rev] = await q("SELECT * FROM reviews WHERE id = LAST_INSERT_ID()");
    res.status(201).json({ ok:true, review: rev });
  } catch (e) {
    res.status(500).json({ ok:false, error: e.message });
  }
});

router.delete('/:id', needAuth(), async (req,res) => {
  try {
    const [r] = await q("SELECT id,user_id FROM reviews WHERE id=?", [req.params.id]);
    if (!r) return res.status(404).json({ ok:false, error:'Reseña no existe' });
    if (r.user_id !== req.user.sub && (req.user.role!=='admin')) return res.status(403).json({ ok:false, error:'No puedes borrar esta reseña' });
    await q("DELETE FROM reviews WHERE id=?", [req.params.id]);
    res.json({ ok:true });
  } catch (e) {
    res.status(500).json({ ok:false, error: e.message });
  }
});

export default router;
