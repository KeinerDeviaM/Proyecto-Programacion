﻿import { APP as APP_CONF } from '../config.js';
import express from 'express';
import jwt from 'jsonwebtoken';
import { q } from '../db.js';
import { hashPass } from '../utils/hash.js';
import { needAuth } from '../middlewares/auth.js';

const router = express.Router();

router.post('/register', async (req,res) => {
  try {
    const { email = '', name = '', password = '' } = req.body || {};
    if (!/^[^@]+@[^@]+\.[^@]+$/.test(email)) return res.status(422).json({ok:false,error:'Email invÃ¡lido'});
    if (!name || String(password).length < 6) return res.status(422).json({ok:false,error:'Nombre y contraseÃ±a requeridos (min 6)'});

    const exists = await q("SELECT id FROM users WHERE email = ?", [email]);
    if (exists.length) return res.status(409).json({ ok:false, error:'El email ya estÃ¡ registrado' });

    const pass_hash = hashPass(email, password);
    await q("INSERT INTO users (email,name,role,pass_hash) VALUES (?,?, 'user', ?)", [email, name, pass_hash]);
    const [user] = await q("SELECT id,email,name,role,created_at FROM users WHERE email = ?", [email]);

    const token = jwt.sign(
      { sub: user.id, email: user.email, name: user.name, role: user.role },
      APP_CONF.SECRET, { expiresIn: APP_CONF.TOKEN_TTL }
    );
    res.status(201).json({ ok:true, token, user });
  } catch (e) {
    res.status(500).json({ ok:false, error: e.message });
  }
});

router.post('/login', async (req,res) => {
  try {
    const { email = '', password = '' } = req.body || {};
    if (!email || !password) return res.status(422).json({ ok:false, error:'Credenciales invÃ¡lidas' });
    const rows = await q("SELECT id,email,name,role,pass_hash,created_at FROM users WHERE email = ?", [email]);
    if (!rows.length) return res.status(404).json({ ok:false, error:'Usuario no encontrado' });
    const user = rows[0];
    const hash = hashPass(email, password);
    if (hash !== user.pass_hash) return res.status(401).json({ ok:false, error:'ContraseÃ±a incorrecta' });
    const token = jwt.sign(
      { sub: user.id, email: user.email, name: user.name, role: user.role },
      APP_CONF.SECRET, { expiresIn: APP_CONF.TOKEN_TTL }
    );
    delete user.pass_hash;
    res.json({ ok:true, token, user });
  } catch (e) {
    res.status(500).json({ ok:false, error: e.message });
  }
});

router.get('/me', needAuth(), async (req,res) => {
  try {
    const [user] = await q("SELECT id,email,name,role,created_at FROM users WHERE id = ?", [req.user.sub]);
    res.json({ ok:true, user });
  } catch (e) {
    res.status(500).json({ ok:false, error: e.message });
  }
});

export default router;

// ... (importaciones existentes)
import nodemailer from 'nodemailer';
// helper transport (SMTP opcional)
function mailer() {
  if (!process.env.SMTP_HOST) return null;
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT || '587', 10),
    secure: process.env.SMTP_SECURE === '1',
    auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined
  });
}

// CAMBIO DE CONTRASEÃ‘A (autenticado)
router.post('/change-password', needAuth(), async (req, res) => {
  try {
    const { current_password = '', new_password = '' } = req.body || {};
    if (String(new_password).length < 6) return res.status(422).json({ ok:false, error:'Nueva contraseÃ±a muy corta' });
    const [user] = await q('SELECT id,email,pass_hash FROM users WHERE id=?', [req.user.sub]);
    if (!user) return res.status(404).json({ ok:false, error:'Usuario no encontrado' });

    const hashNow = hashPass(user.email, current_password);
    if (hashNow !== user.pass_hash) return res.status(401).json({ ok:false, error:'ContraseÃ±a actual incorrecta' });

    const newHash = hashPass(user.email, new_password);
    await q('UPDATE users SET pass_hash=? WHERE id=?', [newHash, user.id]);
    res.json({ ok:true });
  } catch (e) {
    res.status(500).json({ ok:false, error:e.message });
  }
});

// SOLICITAR RECUPERACIÃ“N
router.post('/forgot', async (req, res) => {
  try {
    const { email = '' } = req.body || {};
    const rows = await q('SELECT id,email,name FROM users WHERE email=?', [email]);
    if (!rows.length) return res.json({ ok:true }); // no revelar

    const u = rows[0];
    const token = jwt.sign({ sub: u.id, email: u.email, purpose: 'reset' }, APP_CONF.SECRET, { expiresIn: '15m' });
    const link = `${APP_CONF.PUBLIC_URL}/auth/reset?token=${encodeURIComponent(token)}`;

    const tx = mailer();
    if (tx) {
      await tx.sendMail({
        from: process.env.MAIL_FROM || 'no-reply@localhost',
        to: u.email,
        subject: 'Recupera tu contraseÃ±a',
        html: `<p>Hola ${u.name || ''},</p>
               <p>Para cambiar tu contraseÃ±a haz clic:</p>
               <p><a href="${link}">${link}</a></p>
               <p>Este enlace expira en 15 minutos.</p>`
      });
    }

    // En desarrollo, te devuelvo el token para probar si no usas SMTP
    res.json({ ok:true, token, link });
  } catch (e) {
    res.status(500).json({ ok:false, error:e.message });
  }
});

// RESETEAR CONTRASEÃ‘A (con token)
router.post('/reset', async (req, res) => {
  try {
    const { token = '', new_password = '' } = req.body || {};
    if (String(new_password).length < 6) return res.status(422).json({ ok:false, error:'Nueva contraseÃ±a muy corta' });

    const payload = jwt.verify(token, APP_CONF.SECRET);
    if (payload.purpose !== 'reset') return res.status(400).json({ ok:false, error:'Token invÃ¡lido' });

    const [user] = await q('SELECT id,email FROM users WHERE id=?', [payload.sub]);
    if (!user) return res.status(404).json({ ok:false, error:'Usuario no encontrado' });

    const newHash = hashPass(user.email, new_password);
    await q('UPDATE users SET pass_hash=? WHERE id=?', [newHash, user.id]);
    res.json({ ok:true });
  } catch (e) {
    res.status(400).json({ ok:false, error: e.message });
  }
});

