import fs from 'fs';
import path from 'path';
import PDFDocument from 'pdfkit';

const FACTURAS_DIR = path.join(process.cwd(), 'facturas');
if (!fs.existsSync(FACTURAS_DIR)) fs.mkdirSync(FACTURAS_DIR, { recursive: true });

export function facturaPath(orderId) {
  return path.join(FACTURAS_DIR, `factura_${orderId}.pdf`);
}

export function generarFacturaPDF(order, items) {
  return new Promise((resolve, reject) => {
    try {
      const filePath = facturaPath(order.id);
      const doc = new PDFDocument({ margin: 50 });
      const stream = fs.createWriteStream(filePath);
      doc.pipe(stream);

      // Header
      doc.fontSize(18).text('Mercadito Sport', { align: 'left' });
      doc.moveDown(0.5);
      doc.fontSize(12).text(`Factura #${order.order_code}`);
      doc.text(`Fecha: ${new Date(order.created_at).toLocaleString()}`);
      doc.moveDown();

      // Cliente
      doc.fontSize(14).text('Cliente', { underline:true });
      doc.fontSize(12).text(`${order.first_name} ${order.last_name}`);
      doc.text(order.email);
      doc.text(`${order.phone}`);
      doc.text(order.address);
      doc.text(`${order.city} - ${order.state}`);
      if (order.doc) doc.text(order.doc);
      doc.moveDown();

      // Items
      doc.fontSize(14).text('Items', { underline:true });
      doc.moveDown(0.3);
      doc.fontSize(12);
      const headers = ['Producto', 'Qty', 'Unit', 'Total'];
      const colX = [50, 350, 400, 480];
      headers.forEach((h,i)=> doc.text(h, colX[i], doc.y, { continued: i<headers.length-1 }));
      doc.moveDown(0.5);
      items.forEach(it => {
        const y = doc.y;
        doc.text(it.name_snap, colX[0], y, { width: 280 });
        doc.text(String(it.qty), colX[1], y);
        doc.text(`$${it.unit_price}`, colX[2], y);
        doc.text(`$${it.line_total}`, colX[3], y);
        doc.moveDown(0.2);
      });
      doc.moveDown();

      // Totales
      doc.fontSize(12);
      doc.text(`Subtotal: $${order.sub_total}`, { align:'right' });
      doc.text(`Envío: $${order.ship_total}`, { align:'right' });
      doc.text(`Impuestos: $${order.tax_total}`, { align:'right' });
      doc.fontSize(14).text(`Total: $${order.grand_total}`, { align:'right' });

      doc.moveDown(2);
      doc.fontSize(10).fillColor('#555').text('Gracias por su compra.');

      doc.end();
      stream.on('finish', () => resolve(filePath));
      stream.on('error', reject);
    } catch (e) {
      reject(e);
    }
  });
}
