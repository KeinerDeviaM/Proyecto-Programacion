import jwt from 'jsonwebtoken';
import { APP } from '../config.js';

export function needAuth(roles = null) {
  return (req, res, next) => {
    const hdr = req.headers['authorization'] || req.headers['Authorization'] || '';
    const m = hdr.match(/Bearer\s+(.+)/i);
    if (!m) return res.status(401).json({ ok:false, error:'Missing bearer token' });
    try {
      const payload = jwt.verify(m[1], APP.SECRET);
      if (roles && !roles.includes(payload.role || 'user')) {
        return res.status(403).json({ ok:false, error:'Forbidden' });
      }
      req.user = payload;
      next();
    } catch (e) {
      return res.status(401).json({ ok:false, error:'Invalid token: ' + e.message });
    }
  };
}
