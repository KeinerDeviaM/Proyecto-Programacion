export const APP = {
  NAME: 'Mercadito Sport API',
  SECRET: process.env.APP_SECRET || 'CHANGE_ME',
  TOKEN_TTL: process.env.TOKEN_TTL || '7d',
  PORT: parseInt(process.env.PORT || '4000', 10),
  CORS_ORIGINS: (process.env.CORS_ORIGINS || '*').split(','),
  PUBLIC_URL: process.env.PUBLIC_URL || 'http://localhost:4000'
};

export const DB = {
  host: process.env.DB_HOST || '127.0.0.1',
  port: parseInt(process.env.DB_PORT || '3306', 10),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASS || '',
  database: process.env.DB_NAME || 'mercadito_sport',
  waitForConnections: true,
  connectionLimit: 10,
  charset: 'utf8mb4_general_ci'
};
