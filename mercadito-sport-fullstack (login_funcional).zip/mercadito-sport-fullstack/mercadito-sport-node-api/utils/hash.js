import crypto from 'crypto';
export function hashPass(email, password) {
  const data = (email.trim().toLowerCase() + '::' + String(password));
  const digest = crypto.createHash('sha256').update(data).digest();
  return Buffer.from(digest).toString('base64');
}
