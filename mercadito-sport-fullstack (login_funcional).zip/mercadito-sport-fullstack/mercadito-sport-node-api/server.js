import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { APP } from './config.js';
import authRoutes from './routes/auth.js';
import productsRoutes from './routes/products.js';
import submissionsRoutes from './routes/submissions.js';
import reviewsRoutes from './routes/reviews.js';
import ordersRoutes from './routes/orders.js';
import uploadRoutes from './routes/upload.js';     // << NUEVO
import adminRoutes from './routes/admin.js';       // << NUEVO
import './db.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();

app.use(cors({ origin: (origin, cb) => cb(null, true), credentials: true }));
app.use(express.json({ limit: '5mb' }));

// Estático para uploads y facturas
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));   // << NUEVO
app.use('/facturas', express.static(path.join(__dirname, 'facturas')));

// Rutas
app.use('/auth', authRoutes);
app.use('/products', productsRoutes);
app.use('/submissions', submissionsRoutes);
app.use('/reviews', reviewsRoutes);
app.use('/orders', ordersRoutes);
app.use('/upload', uploadRoutes);     // << NUEVO
app.use('/admin', adminRoutes);       // << NUEVO

app.get('/', (req, res) => res.json({ ok: true, name: APP.NAME }));

app.listen(APP.PORT, () => {
  console.log(`🟢 ${APP.NAME} escuchando en ${APP.PUBLIC_URL}`);
});
