import mysql from 'mysql2/promise';
import { DB } from './config.js';

export const pool = mysql.createPool(DB);

export async function q(sql, params = []) {
  const [rows] = await pool.execute(sql, params);
  return rows;
}
