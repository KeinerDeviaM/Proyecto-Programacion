-- Mercadito Sport — Esquema de Base de Datos (MySQL 8+ / MariaDB 10.6+)
-- Generado 2025-10-26 19:32:04 UTC
-- Charset recomendado: utf8mb4

-- Limpieza opcional (¡cuidado en producción!)
DROP DATABASE IF EXISTS mercadito_sport;
CREATE DATABASE mercadito_sport CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE mercadito_sport;

-- ===== Usuarios =====
CREATE TABLE users (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  email        VARCHAR(120) NOT NULL,
  name         VARCHAR(120) NOT NULL,
  role         ENUM('admin','user') NOT NULL DEFAULT 'user',
  pass_hash    VARCHAR(88) NOT NULL,              -- base64(SHA-256(email::password))
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB;

-- ===== Productos (catálogo aprobado) =====
CREATE TABLE products (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  seller_id    BIGINT UNSIGNED NULL,              -- quien lo subió (users.id), puede ser NULL si es del admin
  name         VARCHAR(180) NOT NULL,
  price_cop    INT UNSIGNED NOT NULL,             -- precio en COP (entero)
  discount_pct TINYINT UNSIGNED NOT NULL DEFAULT 0, -- 0..100
  stock        INT UNSIGNED NOT NULL DEFAULT 0,
  department   ENUM('Novedades','Hombre','Mujer','Junior') NOT NULL DEFAULT 'Novedades',
  sport        VARCHAR(60) NOT NULL DEFAULT 'Training',
  type         VARCHAR(60) NOT NULL DEFAULT 'accesorios',
  brand        VARCHAR(80) NOT NULL DEFAULT 'Marca',
  image_url    TEXT NULL,                          -- imagen principal
  description  TEXT NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_products_dept (department),
  KEY idx_products_sport (sport),
  KEY idx_products_type (type),
  KEY idx_products_brand (brand),
  CONSTRAINT fk_products_seller FOREIGN KEY (seller_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE product_colors (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  product_id BIGINT UNSIGNED NOT NULL,
  name       VARCHAR(40) NOT NULL DEFAULT 'Color',
  hex        CHAR(7) NOT NULL DEFAULT '#111827',   -- #RRGGBB
  PRIMARY KEY (id),
  KEY idx_colors_product (product_id),
  CONSTRAINT fk_colors_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE product_tags (
  product_id BIGINT UNSIGNED NOT NULL,
  tag        VARCHAR(40) NOT NULL,
  PRIMARY KEY (product_id, tag),
  CONSTRAINT fk_tags_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ===== Envíos de producto (pendiente/aprobado/rechazado) =====
-- Los registros aquí representan la "postulación" del vendedor.
-- Si una postulación se aprueba, se crea/actualiza un producto en 'products' y se marca product_id.
CREATE TABLE product_submissions (
  id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  product_id    BIGINT UNSIGNED NULL,              -- producto creado al aprobar (nullable)
  owner_id      BIGINT UNSIGNED NOT NULL,          -- users.id del vendedor
  status        ENUM('pendiente','aprobado','rechazado') NOT NULL DEFAULT 'pendiente',
  name          VARCHAR(180) NOT NULL,
  price_cop     INT UNSIGNED NOT NULL,
  discount_pct  TINYINT UNSIGNED NOT NULL DEFAULT 0,
  stock         INT UNSIGNED NOT NULL DEFAULT 0,
  department    ENUM('Novedades','Hombre','Mujer','Junior') NOT NULL DEFAULT 'Novedades',
  sport         VARCHAR(60) NOT NULL DEFAULT 'Training',
  type          VARCHAR(60) NOT NULL DEFAULT 'accesorios',
  brand         VARCHAR(80) NOT NULL DEFAULT 'Marca',
  image_url     TEXT NULL,
  description   TEXT NULL,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_submissions_status (status),
  KEY idx_submissions_owner (owner_id),
  CONSTRAINT fk_submissions_owner  FOREIGN KEY (owner_id)  REFERENCES users(id)    ON DELETE CASCADE,
  CONSTRAINT fk_submissions_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE submission_colors (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  submission_id BIGINT UNSIGNED NOT NULL,
  name       VARCHAR(40) NOT NULL DEFAULT 'Color',
  hex        CHAR(7) NOT NULL DEFAULT '#111827',
  PRIMARY KEY (id),
  KEY idx_submission_colors (submission_id),
  CONSTRAINT fk_submission_colors FOREIGN KEY (submission_id) REFERENCES product_submissions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE submission_tags (
  submission_id BIGINT UNSIGNED NOT NULL,
  tag           VARCHAR(40) NOT NULL,
  PRIMARY KEY (submission_id, tag),
  CONSTRAINT fk_submission_tags FOREIGN KEY (submission_id) REFERENCES product_submissions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ===== Reseñas =====
CREATE TABLE reviews (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  product_id BIGINT UNSIGNED NOT NULL,
  user_id    BIGINT UNSIGNED NOT NULL,
  rating     TINYINT UNSIGNED NOT NULL,           -- 1..5
  title      VARCHAR(160) NULL,
  body       TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_reviews_product (product_id),
  KEY idx_reviews_user (user_id),
  CONSTRAINT ck_reviews_rating CHECK (rating BETWEEN 1 AND 5),
  CONSTRAINT fk_reviews_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  CONSTRAINT fk_reviews_user    FOREIGN KEY (user_id)    REFERENCES users(id)    ON DELETE CASCADE
) ENGINE=InnoDB;

-- ===== Órdenes =====
CREATE TABLE orders (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  order_code   VARCHAR(24) NOT NULL,              -- ej: MSK8D2...
  user_id      BIGINT UNSIGNED NULL,              -- puede ser NULL si fue invitado
  status       ENUM('pagado','enviado','cancelado') NOT NULL DEFAULT 'pagado',
  sub_total    INT UNSIGNED NOT NULL DEFAULT 0,
  ship_total   INT UNSIGNED NOT NULL DEFAULT 0,
  tax_total    INT UNSIGNED NOT NULL DEFAULT 0,
  grand_total  INT UNSIGNED NOT NULL DEFAULT 0,
  -- datos de envío/facturación (desde checkout.html)
  first_name   VARCHAR(80) NOT NULL,
  last_name    VARCHAR(80) NOT NULL,
  email        VARCHAR(120) NOT NULL,
  phone        VARCHAR(40)  NOT NULL,
  address      VARCHAR(180) NOT NULL,
  city         VARCHAR(80)  NOT NULL,
  state        VARCHAR(80)  NOT NULL,
  zip          VARCHAR(20)  NOT NULL,
  doc          VARCHAR(40)  NULL,                -- cédula/NIT opcional
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_orders_code (order_code),
  KEY idx_orders_user (user_id),
  CONSTRAINT fk_orders_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE order_items (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  order_id    BIGINT UNSIGNED NOT NULL,
  product_id  BIGINT UNSIGNED NOT NULL,
  qty         INT UNSIGNED NOT NULL,
  unit_price  INT UNSIGNED NOT NULL,
  line_total  INT UNSIGNED NOT NULL,
  name_snap   VARCHAR(180) NOT NULL,             -- nombre al momento de compra
  brand_snap  VARCHAR(80)  NOT NULL,             -- marca al momento de compra
  image_snap  TEXT NULL,                          -- imagen al momento de compra
  PRIMARY KEY (id),
  KEY idx_order_items_order (order_id),
  KEY idx_order_items_product (product_id),
  CONSTRAINT fk_order_items_order   FOREIGN KEY (order_id)   REFERENCES orders(id)   ON DELETE CASCADE,
  CONSTRAINT fk_order_items_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ===== Vistas útiles =====
-- Agregados de reseñas por producto
CREATE OR REPLACE VIEW vw_products_with_rating AS
SELECT
  p.*,
  COALESCE(AVG(r.rating), 0) AS avg_rating,
  COUNT(r.id)                AS reviews_count
FROM products p
LEFT JOIN reviews r ON r.product_id = p.id
GROUP BY p.id;

-- Buscador sencillo (nombre/brand/tags)
CREATE OR REPLACE VIEW vw_products_search AS
SELECT p.id, p.name, p.brand, p.department, p.sport, p.type, p.price_cop, p.discount_pct,
       GROUP_CONCAT(DISTINCT pt.tag ORDER BY pt.tag SEPARATOR ',') AS tags
FROM products p
LEFT JOIN product_tags pt ON pt.product_id = p.id
GROUP BY p.id;

-- ===== Restricciones adicionales =====
ALTER TABLE products
  ADD CONSTRAINT ck_products_discount CHECK (discount_pct BETWEEN 0 AND 100);
